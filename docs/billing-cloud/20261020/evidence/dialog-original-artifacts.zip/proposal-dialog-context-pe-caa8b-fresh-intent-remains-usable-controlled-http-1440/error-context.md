# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: proposal-dialog-context.spec.ts >> pending proposal cannot replace the issuer dialog; fresh intent remains usable
- Location: tools\oier_billing_qa\proposal-dialog-context.spec.ts:8:44

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByRole('dialog', { name: 'Revisar borrador local', exact: true })
Expected: 0
Received: 1
Timeout:  4000ms

Call log:
  - Expect "toHaveCount" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Revisar borrador local', exact: true })
    12 × locator resolved to 1 element
       - unexpected value "1"

```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test'
  2  | import {startBillingFocusFixture} from '../../tests/e2e-preview/fixtures/billing-focus-server.cjs'
  3  | import {calculateBillingV1} from '../../src/lib/server/billing-runtime-v1'
  4  | let fixture:Awaited<ReturnType<typeof startBillingFocusFixture>>
  5  | test.beforeAll(async()=>{fixture=await startBillingFocusFixture()})
  6  | test.afterAll(async()=>{await fixture?.close()})
  7  | const modes=[['issuer','Configurar emisor','Datos fiscales del emisor'],['customer','Datos fiscales del cliente','Datos fiscales del cliente'],['summary','Ver resumen','Resumen de factura'],['payment','Marcar como cobrada','Registrar cobro']] as const
  8  | for(const [mode,button,title] of modes)test(`pending proposal cannot replace the ${mode} dialog; fresh intent remains usable`,async({page},info)=>{
  9  |  const customer=fixture.invoice.customer_id,commands:string[]=[],errors:string[]=[]
  10 |  let release=()=>{},held=false,done=false,proposals=0
  11 |  const gate=new Promise<void>(resolve=>release=resolve)
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const request=route.request(),body=request.postDataJSON()
  15 |   if(new URL(request.url()).pathname.includes('/commands')){commands.push(body.operation);await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  16 |   if(body.operation==='global.search'){await route.fulfill({json:{ok:true,data:{contract_version:'product.v1',items:[{kind:'customer',id:customer,customer_id:customer,label:'Bilbao Telecom Demo SL',status:'active'}]}}});return}
  17 |   if(body.operation==='invoice.list'){
  18 |    const invoice=Object.fromEntries(['currency','customer_id','due_on','id','issue_on','number','overdue','series','status','totals','version'].map(key=>[key,fixture.invoice[key as keyof typeof fixture.invoice]]))
  19 |    await route.fulfill({json:{ok:true,data:{contract_version:'billing.v1',operation:body.operation,items:[invoice],next_id:null}}});return
  20 |   }
  21 |   if(body.operation==='invoice.private_pdf_reference'){await route.fulfill({status:404,json:{ok:false,error:'not_found'}});return}
  22 |   if(body.operation==='invoice.propose'){
  23 |    const first=++proposals===1
  24 |    if(first){held=true;await gate}
  25 |    await route.fulfill({json:{ok:true,data:{contract_version:'billing.v1',operation:body.operation,source:body.input.source,draft:body.input.draft,totals:calculateBillingV1(body.input.draft.lines),requires_review:true,saved:false}}})
  26 |    if(first)done=true
  27 |    return
  28 |   }
  29 |   // Summary refusal is deliberate: its authorized error dialog must also remain current.
  30 |   if(body.operation==='invoice.summary'){await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  31 |   await route.continue()
  32 |  })
  33 |  try{
  34 |   await page.goto(fixture.url)
  35 |   await page.getByRole('textbox',{name:'Buscar cliente de factura',exact:true}).fill('Bilbao')
  36 |   await page.getByRole('button',{name:'Buscar cliente',exact:true}).click()
  37 |   await page.getByRole('combobox',{name:'Cliente para facturación',exact:true}).selectOption(customer)
  38 |   if(mode==='payment'){
  39 |    await page.getByRole('button',{name:'Abrir factura',exact:true}).click()
  40 |    await expect(page.locator('section[data-invoice-detail-id]')).toBeVisible()
  41 |   }
  42 |   const text=page.getByRole('textbox',{name:'Descripción de la factura',exact:true})
  43 |   await text.fill('Factura para Bilbao Telecom Demo SL de 300 euros por soporte')
  44 |   await page.getByRole('button',{name:'Generar propuesta',exact:true}).click()
  45 |   await expect.poll(()=>held).toBe(true)
  46 |   await page.getByRole('button',{name:button,exact:true}).click()
  47 |   const dialog=page.getByRole('dialog',{name:title,exact:true})
  48 |   await expect(dialog).toBeVisible()
  49 |   release();await expect.poll(()=>done).toBe(true)
  50 |   await page.evaluate(()=>new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve()))))
> 51 |   await expect(page.getByRole('dialog',{name:'Revisar borrador local',exact:true})).toHaveCount(0)
     |                                                                                     ^ Error: expect(locator).toHaveCount(expected) failed
  52 |   await expect(dialog).toBeVisible()
  53 |   expect(commands).toEqual([]);expect(errors).toEqual([])
  54 |   await page.screenshot({path:info.outputPath(`current-${mode}-dialog.png`)})
  55 |   await page.keyboard.press('Escape');await expect(dialog).toHaveCount(0)
  56 |   await page.getByRole('button',{name:'Generar propuesta',exact:true}).click()
  57 |   await expect(page.getByLabel('Concepto 1',{exact:true})).toHaveValue('soporte')
  58 |   expect(proposals).toBe(2);expect(commands).toEqual([]);expect(errors).toEqual([])
  59 |  }finally{release();await page.unrouteAll({behavior:'wait'})}
  60 | })
  61 | 
```
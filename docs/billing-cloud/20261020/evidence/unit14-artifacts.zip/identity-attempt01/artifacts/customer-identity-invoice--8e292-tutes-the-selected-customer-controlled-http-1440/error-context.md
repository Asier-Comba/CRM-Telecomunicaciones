# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: customer-identity.spec.ts >> invoice identity different_name never silently substitutes the selected customer
- Location: tools\oier_billing_qa\customer-identity.spec.ts:9:106

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByLabel('Cliente de factura', { exact: true })
Expected: 0
Received: 1
Timeout:  4000ms

Call log:
  - Expect "toHaveCount" with timeout 4000ms
  - waiting for getByLabel('Cliente de factura', { exact: true })
    12 × locator resolved to 1 element
       - unexpected value "1"

```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test'
  2  | import {startBillingFocusFixture} from '../../tests/e2e-preview/fixtures/billing-focus-server.cjs'
  3  | import {calculateBillingV1} from '../../src/lib/server/billing-runtime-v1'
  4  | let fixture:Awaited<ReturnType<typeof startBillingFocusFixture>>
  5  | test.beforeAll(async()=>{fixture=await startBillingFocusFixture()})
  6  | test.afterAll(async()=>{await fixture?.close()})
  7  | const a='10000000-0000-4000-8000-000000000001',b='10000000-0000-4000-8000-000000000003'
  8  | const clients=[{id:a,name:'Bilbao Telecom Demo SL'},{id:b,name:'Bilbao Redes Demo SL'}]
  9  | for(const mode of ['different_name','ambiguous_name','selected_name','corrected_selection'] as const)test(`invoice identity ${mode} never silently substitutes the selected customer`,async({page},info)=>{
  10 |  const proposals:string[]=[],commands:string[]=[],errors:string[]=[]
  11 |  page.on('pageerror',e=>errors.push(e.message))
  12 |  await page.route('**/api/**',async route=>{
  13 |   const request=route.request(),body=request.postDataJSON()
  14 |   if(new URL(request.url()).pathname.includes('/commands')){commands.push(body.operation);await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  15 |   if(body.operation==='global.search'){await route.fulfill({json:{ok:true,data:{contract_version:'product.v1',items:clients.map(c=>({kind:'customer',id:c.id,customer_id:c.id,label:c.name,status:'active'}))}}});return}
  16 |   if(body.operation==='invoice.list'){await route.fulfill({json:{ok:true,data:{contract_version:'billing.v1',operation:body.operation,items:[],next_id:null}}});return}
  17 |   if(body.operation==='invoice.private_pdf_reference'){await route.fulfill({status:404,json:{ok:false,error:'not_found'}});return}
  18 |   if(body.operation==='invoice.propose'){proposals.push(body.input.draft.customer_id);await route.fulfill({json:{ok:true,data:{contract_version:'billing.v1',operation:body.operation,source:body.input.source,draft:body.input.draft,totals:calculateBillingV1(body.input.draft.lines),requires_review:true,saved:false}}});return}
  19 |   await route.continue()
  20 |  })
  21 |  try{
  22 |   await page.goto(fixture.url)
  23 |   await page.getByRole('textbox',{name:'Buscar cliente de factura',exact:true}).fill('Bilbao')
  24 |   await page.getByRole('button',{name:'Buscar cliente',exact:true}).click()
  25 |   const selection=page.getByRole('combobox',{name:'Cliente para facturación',exact:true})
  26 |   await selection.selectOption(b)
  27 |   if(mode==='corrected_selection')await selection.selectOption(a)
  28 |   const name=mode==='ambiguous_name'?'Bilbao':clients[mode==='selected_name'?1:0].name
  29 |   await page.getByRole('textbox',{name:'Descripción de la factura',exact:true}).fill(`Factura para ${name} de 300 euros por soporte`)
  30 |   await page.getByRole('button',{name:'Generar propuesta',exact:true}).click()
  31 |   const warning=page.getByRole('alert').filter({hasText:'El cliente del texto no coincide de forma inequívoca con el seleccionado.'})
  32 |   if(mode==='different_name'||mode==='ambiguous_name'){
  33 |    await expect.poll(async()=>await warning.count()>0||await page.getByLabel('Cliente de factura',{exact:true}).count()>0).toBe(true)
  34 |    const editor=await page.getByLabel('Cliente de factura',{exact:true}).evaluateAll(elements=>elements.map(e=>(e as HTMLSelectElement).value))
  35 |    await info.attach('identity-observation',{body:JSON.stringify({named:name,selected:await selection.inputValue(),proposals,editor}),contentType:'application/json'})
> 36 |    await expect(page.getByLabel('Cliente de factura',{exact:true})).toHaveCount(0)
     |                                                                     ^ Error: expect(locator).toHaveCount(expected) failed
  37 |    await expect(warning).toBeVisible();expect(proposals).toEqual([])
  38 |   }else{
  39 |    const expected=mode==='selected_name'?b:a
  40 |    await expect(page.getByLabel('Cliente de factura',{exact:true})).toHaveValue(expected)
  41 |    await expect(page.getByLabel('Concepto 1',{exact:true})).toHaveValue('soporte')
  42 |    expect(proposals).toEqual([expected]);await expect(warning).toHaveCount(0)
  43 |   }
  44 |   expect(commands).toEqual([]);expect(errors).toEqual([])
  45 |   await page.screenshot({path:info.outputPath(`identity-${mode}.png`)})
  46 |  }finally{await page.unrouteAll({behavior:'wait'})}
  47 | })
  48 | 
```
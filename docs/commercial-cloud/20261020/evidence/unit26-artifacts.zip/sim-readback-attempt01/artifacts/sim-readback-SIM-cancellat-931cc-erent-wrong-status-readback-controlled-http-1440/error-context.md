# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sim-readback.spec.ts >> SIM cancellation receipt keeps coherent wrong_status readback
- Location: tools\oier_commercial_qa\sim-readback.spec.ts:8:88

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('button', { name: 'Actualizar lectura', exact: true })
Expected: enabled
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" with timeout 4000ms
  - waiting for getByRole('button', { name: 'Actualizar lectura', exact: true })

```

```yaml
- banner: CRM synthetic telecom resource fixture
- main:
  - button "Cambiar empresa sintética"
  - button "Cambiar actor sintético"
  - button "Cambiar a lector sintético"
  - text: Empresa sintética A
  - navigation "Recurso sintético seleccionado":
    - button "Seleccionar recurso A"
    - button "Seleccionar recurso B"
    - button "Seleccionar recurso C"
    - button "Seleccionar recurso D"
    - status "Referencia de recurso actual": 40000000-0000-4000-8000-000000000001
  - heading "SIM sintética preparada sin identificadores" [level=1]
  - text: Preparada SIM física
  - link "Cliente sintético de SIM":
    - /url: /clients/10000000-0000-4000-8000-000000000001
  - text: Operador sintético
  - term: ICCID
  - definition: No registrado
  - term: Activación registrada
  - definition: Sin fecha
  - term: Último cambio
  - definition: 20 oct 2026, 08:00
  - paragraph: Se registra seguimiento interno. La activación requiere confirmación recibida del operador; esta pantalla no activa servicios externos.
  - heading "Preparación y asignación" [level=2]
  - button "Gestionar identificadores de SIM/eSIM"
  - text: Línea para SIM
  - combobox "Línea para SIM":
    - option "Selecciona una línea" [selected]
  - button "Líneas anteriores" [disabled]
  - button "Más líneas" [disabled]
  - button "Actualizar líneas disponibles"
  - paragraph: Líneas manuales autorizadas, hasta 20 por página. El servidor comprueba contrato, servicio y versión antes de guardar.
  - button "Revisar asignación de SIM/eSIM" [disabled]
  - paragraph: Registra un ICCID antes de asignar.
  - button "Revisar cancelación de SIM/eSIM"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startTelecomResourceFixture} from '../../tests/e2e-preview/fixtures/telecom-resource-server.cjs'
  3  | const id='40000000-0000-4000-8000-000000000001',customer='10000000-0000-4000-8000-000000000001',operator='20000000-0000-4000-8000-000000000001'
  4  | const title='SIM sintética preparada sin identificadores'
  5  | let fixture:Awaited<ReturnType<typeof startTelecomResourceFixture>>
  6  | test.beforeAll(async()=>{fixture=await startTelecomResourceFixture()})
  7  | test.afterAll(async()=>{await fixture?.close()})
  8  | for(const mode of ['stale','wrong_status','wrong_source','exact','newer'] as const)test(`SIM cancellation receipt keeps coherent ${mode} readback`,async({page},info)=>{
  9  |  const commands:{operation:string;input:Record<string,unknown>}[]=[],errors:string[]=[]
  10 |  let applied=false,corrected=false,readbacks=0
  11 |  const initial={id,version:1,customer_id:customer,operator_id:operator,kind:'physical',display_label:title,status:'prepared',source:'manual',masked_iccid:null,masked_eid:null,assigned_line_id:null,activated_at:null,replaced_at:null,deactivated_at:null,cancelled_at:null,created_at:'2026-10-11T12:00:00Z',updated_at:'2026-10-11T12:00:00Z'}
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const q=route.request().postDataJSON();let data:unknown
  15 |   if(q.operation==='sim.cancel'){
  16 |    commands.push(q);applied=true
  17 |    data={contract_version:'sim.v1',operation:q.operation,command_id:q.input.command_id,id,version:2,status:'cancelled',source:'manual',association_id:null,replacement_id:null,replacement_version:null,replacement_status:null,replacement_association_id:null}
  18 |   }else if(q.operation==='sim.get'){
  19 |    if(applied)readbacks++
  20 |    const old=!applied||!corrected&&mode==='stale',cancelled=corrected||mode!=='wrong_status'
  21 |    const record=old?initial:{...initial,version:mode==='newer'?3:2,status:cancelled?'cancelled':'prepared',source:!corrected&&mode==='wrong_source'?'integration':'manual',cancelled_at:cancelled?'2026-10-20T06:00:00Z':null,updated_at:'2026-10-20T06:00:00Z'}
  22 |    data={contract_version:'sim.v1',operation:q.operation,record}
  23 |   }else if(q.operation==='customer.list')data={contract_version:'telecom.collections.v1',operation:q.operation,items:[{id:customer,version:1,display_name:'Cliente sintético de SIM',account_kind:'legal_entity',lifecycle:'customer',status:'active',source:'manual',assigned_user_id:null}],next_id:null}
  24 |   else if(q.operation==='operator.get')data={contract_version:'telecom.collections.v1',operation:q.operation,record:{id:operator,version:1,code:'oier_synthetic',display_name:'Operador sintético',status:'active',source:'manual'}}
  25 |   else if(q.operation==='line.list')data={contract_version:'telecom.collections.v1',operation:q.operation,items:[],next_id:null}
  26 |   else{await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  27 |   await route.fulfill({json:{ok:true,data}})
  28 |  })
  29 |  try{
  30 |   await page.goto(fixture.url+'/?kind=sim')
  31 |   const review=page.getByRole('button',{name:'Revisar cancelación de SIM/eSIM',exact:true})
  32 |   await expect(page.getByRole('heading',{name:title,exact:true})).toBeVisible();await expect(review).toBeEnabled()
  33 |   await review.click()
  34 |   const confirm=page.getByRole('dialog',{name:'Confirmar cambio de SIM/eSIM',exact:true})
  35 |   await confirm.getByRole('button',{name:'Confirmar cambio',exact:true}).click()
  36 |   await expect.poll(()=>readbacks>0).toBe(true)
  37 |   if(['stale','wrong_status','wrong_source'].includes(mode)){
  38 |    const retry=page.getByRole('button',{name:'Actualizar lectura',exact:true})
  39 |    await info.attach('confirmed-readback-observation',{body:JSON.stringify({mode,commands,readbacks,reviewCount:await review.count(),retryCount:await retry.count()}),contentType:'application/json'})
> 40 |    await expect(retry).toBeEnabled();await expect(review).toBeDisabled();await expect(confirm).toHaveCount(0)
     |                        ^ Error: expect(locator).toBeEnabled() failed
  41 |    await expect(page.getByRole('status').filter({hasText:'Cambio registrado. Reintentar solo actualiza la lectura.'})).toBeVisible()
  42 |    await retry.scrollIntoViewIfNeeded();await page.screenshot({path:info.outputPath(`sim-${mode}-registered.png`)})
  43 |    corrected=true;await retry.click()
  44 |   }
  45 |   await expect(page.getByText('Cancelado',{exact:true})).toBeVisible()
  46 |   await expect(review).toHaveCount(0)
  47 |   expect(commands).toHaveLength(1);expect(commands[0].operation).toBe('sim.cancel')
  48 |   expect(Object.keys(commands[0].input).sort()).toEqual(['command_id','expected_version','id'])
  49 |   expect(commands[0].input).toMatchObject({id,expected_version:1})
  50 |   expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  51 |   await page.locator('#main-content').evaluate(el=>{el.scrollTop=0})
  52 |   await page.screenshot({path:info.outputPath(`sim-${mode}-coherent.png`)})
  53 |  }finally{await page.close()}
  54 | })
  55 | 
```
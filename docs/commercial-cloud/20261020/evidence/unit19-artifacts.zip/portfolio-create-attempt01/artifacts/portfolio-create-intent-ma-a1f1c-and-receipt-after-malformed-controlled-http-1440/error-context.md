# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio-create-intent.spec.ts >> manual service creation preserves intent and receipt after malformed
- Location: tools\oier_commercial_qa\portfolio-create-intent.spec.ts:9:99

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  getByRole('dialog', { name: 'Registrar activo manual', exact: true }).getByLabel('Nombre del nuevo activo', { exact: true })
Expected: disabled
Received: enabled
Timeout:  4000ms

Call log:
  - Expect "toBeDisabled" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Registrar activo manual', exact: true }).getByLabel('Nombre del nuevo activo', { exact: true })
    12 × locator resolved to <input required="" maxlength="160" value="Reviewed manual service" class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 disabled:opacity-50 w-full"/>
       - unexpected value "enabled"

```

```yaml
- textbox "Nombre del nuevo activo": Reviewed manual service
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startCommercialResourceFixture} from '../../tests/e2e-preview/fixtures/commercial-resource-server.cjs'
  3  | const contract='60000000-0000-4000-8000-000000000001',service='40000000-0000-4000-8000-000000000001',customer='10000000-0000-4000-8000-000000000001'
  4  | const parent={id:contract,version:1,status:'active',source:'manual',customer_id:customer,operator_id:'20000000-0000-4000-8000-000000000001',plan_version_id:null,start_date:'2026-10-01',signed_date:'2026-10-01',end_date:null,assigned_user_id:null}
  5  | const child={id:service,version:1,status:'pending',source:'manual',customer_id:customer,contract_id:contract,operator_id:parent.operator_id,plan_version_id:null,service_kind:'mobile',display_name:'Reviewed manual service',activated_on:null,ended_on:null,status_effective_on:null}
  6  | let fixture:Awaited<ReturnType<typeof startCommercialResourceFixture>>
  7  | test.beforeAll(async()=>{fixture=await startCommercialResourceFixture()})
  8  | test.afterAll(async()=>{await fixture?.close()})
  9  | for(const mode of ['transport','malformed','wrong_receipt','read_failure','success'] as const)test(`manual service creation preserves intent and receipt after ${mode}`,async({page},info)=>{
  10 |  const commands:{operation:string;input:{command_id:string}}[]=[],errors:string[]=[]
  11 |  let reads=0,permitRead=false
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const q=route.request().postDataJSON()
  15 |   if(route.request().url().endsWith('/commands')){
  16 |    commands.push(q)
  17 |    if(commands.length===1){
  18 |     if(mode==='transport'){await route.abort('failed');return}
  19 |     if(mode==='malformed'){await route.fulfill({status:200,contentType:'application/json',body:'{'});return}
  20 |    }
  21 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'portfolio.v1',operation:q.operation,command_id:commands.length===1&&mode==='wrong_receipt'?'70000000-0000-4000-8000-000000000009':q.input.command_id,id:service,version:1,status:'pending',source:'manual'}}});return
  22 |   }
  23 |   if(q.operation==='portfolio.get'){
  24 |    if(q.input.kind==='service'){
  25 |     reads++
  26 |     if(mode==='read_failure'&&!permitRead){await route.fulfill({status:503,json:{ok:false,error:'unavailable'}});return}
  27 |     await route.fulfill({json:{ok:true,data:{contract_version:'portfolio.v1',kind:'service',record:child}}});return
  28 |    }
  29 |    await route.fulfill({json:{ok:true,data:{contract_version:'portfolio.v1',kind:'contract',record:parent}}});return
  30 |   }
  31 |   if(q.operation==='customer.list'){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation:q.operation,items:[{id:customer,version:1,display_name:'Synthetic service customer',account_kind:'legal_entity',lifecycle:'customer',status:'active',source:'manual',assigned_user_id:null}],next_id:null}}});return}
  32 |   if(['contract.list','service.list','line.list','assignee.list'].includes(q.operation)){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation:q.operation,items:[],next_id:null}}});return}
  33 |   await route.fulfill({status:403,json:{ok:false,error:'access_denied'}})
  34 |  })
  35 |  try{
  36 |   await page.goto(fixture.url+'/?kind=portfolio&portfolio_reference='+contract)
  37 |   await page.getByRole('dialog',{name:'Contrato: Contrato',exact:true}).getByRole('button',{name:'Cerrar panel',exact:true}).click()
  38 |   await page.locator(`article[data-portfolio-id="${contract}"]`).getByRole('button',{name:'Añadir servicio o plazo',exact:true}).click()
  39 |   const drawer=page.getByRole('dialog',{name:'Registrar activo manual',exact:true}),name=drawer.getByLabel('Nombre del nuevo activo',{exact:true})
  40 |   await name.fill(child.display_name)
  41 |   await drawer.getByRole('button',{name:'Guardar activo manual',exact:true}).click()
  42 |   await expect.poll(()=>commands.length).toBe(1)
  43 |   if(mode!=='success'){
  44 |    await expect(drawer.getByRole('alert')).toBeVisible()
  45 |    if(mode==='read_failure')await expect(drawer.getByRole('button',{name:'Consultar el alta registrada',exact:true})).toBeVisible()
  46 |    await info.attach('creation-observation',{body:JSON.stringify({mode,commands,reads}),contentType:'application/json'})
> 47 |    await expect(name).toBeDisabled()
     |                       ^ Error: expect(locator).toBeDisabled() failed
  48 |    await drawer.getByRole('button',{name:'Cerrar panel',exact:true}).click({force:true});await expect(drawer).toBeVisible()
  49 |    await page.keyboard.press('Escape');await expect(drawer).toBeVisible()
  50 |    await drawer.getByRole('alert').scrollIntoViewIfNeeded()
  51 |    await page.screenshot({path:info.outputPath(`service-create-${mode}-pending.png`)})
  52 |    permitRead=true
  53 |    await drawer.getByRole('button',{name:mode==='read_failure'?'Consultar el alta registrada':'Reintentar la misma acción',exact:true}).click()
  54 |    if(mode==='read_failure')await expect.poll(()=>reads).toBe(2)
  55 |    else{await expect.poll(()=>commands.length).toBe(2);expect(commands[1]).toEqual(commands[0])}
  56 |   }
  57 |   await expect(drawer).toHaveCount(0)
  58 |   const card=page.locator(`article[data-portfolio-id="${service}"]`)
  59 |   await expect(card.getByRole('heading',{name:child.display_name,exact:true})).toBeVisible()
  60 |   expect(commands.map(c=>c.operation)).toEqual(Array(mode==='success'||mode==='read_failure'?1:2).fill('service.create_manual'))
  61 |   expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  62 |   await card.scrollIntoViewIfNeeded();await page.screenshot({path:info.outputPath(`service-create-${mode}-current.png`)})
  63 |  }finally{await page.close()}
  64 | })
  65 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio-create-intent.spec.ts >> manual service creation preserves intent and receipt after read_failure
- Location: tools\oier_commercial_qa\portfolio-create-intent.spec.ts:9:99

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog', { name: 'Registrar activo manual', exact: true })
Expected: visible
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Registrar activo manual', exact: true })

```

```yaml
- banner: CRM synthetic commercial resource fixture
- main:
  - button "Cambiar empresa sintética"
  - button "Cambiar actor sintético"
  - button "Cambiar a lector sintético"
  - text: Empresa sintética A
  - navigation "Contexto de referencia sintética":
    - button "Actualizar contexto sintético"
    - button "Cambiar referencia sintética"
    - status "Versión de contexto sintético": "0"
  - heading "Cartera Telecom" [level=1]
  - paragraph: Activos autorizados y plazos registrados
  - strong: Integración local
  - text: · Datos sintéticos de prueba · Cambios guardados en la base local
  - tablist "Secciones":
    - tab "Contratos" [selected]
    - tab "Servicios"
    - tab "Líneas"
    - tab "SIM/eSIM"
    - tab "Portabilidades"
    - tab "Renovaciones"
    - tab "Permanencias"
    - tab "Incidencias"
    - tab "Equipos"
  - tabpanel "Contratos":
    - button "Registrar contrato manual"
    - heading "Contratos" [level=2]
    - paragraph: Inventario del espacio autorizado · páginas independientes de hasta 20 registros.
    - combobox "Estado de Contratos":
      - option "Todos los estados" [selected]
      - option "Borrador"
      - option "Activo"
      - option "Finalizado"
      - option "Cancelado"
    - button "Actualizar Contratos"
    - paragraph: No hay registros de contratos en esta página.
    - button "Página anterior de Contratos" [disabled]
    - text: Página 1 · 0 registros
    - button "Siguiente página de Contratos" [disabled]
  - heading "Consulta rápida y edición de activos" [level=2]
  - textbox "Consultar cartera local":
    - /placeholder: Buscar empresa o activo
  - button "Consultar cartera"
  - paragraph: Hasta cinco resultados por familia en cada búsqueda. No es el inventario completo. Operadores y tarifas requieren un catálogo de selección autorizado.
  - article:
    - paragraph: "Contrato · Origen: Manual"
    - heading "Contrato" [level=2]
    - text: Activo
    - button "Ver activo"
    - button "Añadir servicio o plazo"
  - region "Gestión de importaciones":
    - heading "Trabajos de importación" [level=2]
    - paragraph: Consulta y cancelación de trabajos existentes. La carga, validación y aplicación de archivos todavía no están disponibles. El procesamiento sigue bloqueado.
    - combobox "Estado de importaciones":
      - option "Todos los estados" [selected]
      - option "Cargado"
      - option "Asignación de columnas"
      - option "En validación"
      - option "Preparado"
      - option "En aplicación"
      - option "Completado"
      - option "Fallido"
      - option "Cancelado"
    - button "Actualizar importaciones"
    - alert: No tienes permiso para esta acción.
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startCommercialResourceFixture} from '../../tests/e2e-preview/fixtures/commercial-resource-server.cjs'
  3  | const contract='60000000-0000-4000-8000-000000000001',service='40000000-0000-4000-8000-000000000001',customer='10000000-0000-4000-8000-000000000001'
  4  | const parent={id:contract,version:1,status:'active',source:'manual',customer_id:customer,operator_id:'20000000-0000-4000-8000-000000000001',plan_version_id:null,start_date:'2026-10-01',signed_date:'2026-10-01',end_date:null,assigned_user_id:null}
  5  | const child={id:service,version:1,status:'pending',source:'manual',customer_id:customer,contract_id:contract,operator_id:parent.operator_id,plan_version_id:null,service_kind:'mobile',display_name:'Reviewed manual service',activated_on:null,ended_on:null,status_effective_on:null}
  6  | let fixture:Awaited<ReturnType<typeof startCommercialResourceFixture>>
  7  | test.beforeAll(async()=>{fixture=await startCommercialResourceFixture()})
  8  | test.afterAll(async()=>{await fixture?.close()})
  9  | for(const mode of ['transport','malformed','wrong_receipt','read_failure','success'] as const)test(`manual service creation preserves intent and receipt after ${mode}`,async({page},info)=>{
  10 |  const commands:{operation:string;input:{command_id:string}}[]=[],errors:string[]=[]
  11 |  let reads=0,permitRead=false
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const q=route.request().postDataJSON()
  15 |   if(route.request().url().endsWith('/commands')){
  16 |    commands.push(q)
  17 |    if(commands.length===1){
  18 |     if(mode==='transport'){await route.abort('failed');return}
  19 |     if(mode==='malformed'){await route.fulfill({status:200,contentType:'application/json',body:'{'});return}
  20 |    }
  21 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'portfolio.v1',operation:q.operation,command_id:commands.length===1&&mode==='wrong_receipt'?'70000000-0000-4000-8000-000000000009':q.input.command_id,id:service,version:1,status:'pending',source:'manual'}}});return
  22 |   }
  23 |   if(q.operation==='portfolio.get'){
  24 |    if(q.input.kind==='service'){
  25 |     reads++
  26 |     if(mode==='read_failure'&&!permitRead){await route.fulfill({status:503,json:{ok:false,error:'unavailable'}});return}
  27 |     await route.fulfill({json:{ok:true,data:{contract_version:'portfolio.v1',kind:'service',record:child}}});return
  28 |    }
  29 |    await route.fulfill({json:{ok:true,data:{contract_version:'portfolio.v1',kind:'contract',record:parent}}});return
  30 |   }
  31 |   if(q.operation==='customer.list'){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation:q.operation,items:[{id:customer,version:1,display_name:'Synthetic service customer',account_kind:'legal_entity',lifecycle:'customer',status:'active',source:'manual',assigned_user_id:null}],next_id:null}}});return}
  32 |   if(['contract.list','service.list','line.list','assignee.list'].includes(q.operation)){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation:q.operation,items:[],next_id:null}}});return}
  33 |   await route.fulfill({status:403,json:{ok:false,error:'access_denied'}})
  34 |  })
  35 |  try{
  36 |   await page.goto(fixture.url+'/?kind=portfolio&portfolio_reference='+contract)
  37 |   await page.getByRole('dialog',{name:'Contrato: Contrato',exact:true}).getByRole('button',{name:'Cerrar panel',exact:true}).click()
  38 |   await page.locator(`article[data-portfolio-id="${contract}"]`).getByRole('button',{name:'Añadir servicio o plazo',exact:true}).click()
  39 |   const drawer=page.getByRole('dialog',{name:'Registrar activo manual',exact:true}),name=drawer.getByLabel('Nombre del nuevo activo',{exact:true})
  40 |   await name.fill(child.display_name)
  41 |   await drawer.getByRole('button',{name:'Guardar activo manual',exact:true}).click()
  42 |   await expect.poll(()=>commands.length).toBe(1)
  43 |   if(mode!=='success'){
  44 |    await expect(drawer.getByRole('alert')).toBeVisible()
  45 |    if(mode==='read_failure')await expect(drawer.getByRole('button',{name:'Consultar el alta registrada',exact:true})).toBeVisible()
  46 |    await info.attach('creation-observation',{body:JSON.stringify({mode,commands,reads}),contentType:'application/json'})
  47 |    await expect(name).toBeDisabled()
> 48 |    await drawer.getByRole('button',{name:'Cerrar panel',exact:true}).click({force:true});await expect(drawer).toBeVisible()
     |                                                                                                               ^ Error: expect(locator).toBeVisible() failed
  49 |    await page.keyboard.press('Escape');await expect(drawer).toBeVisible()
  50 |    await drawer.getByRole('alert').scrollIntoViewIfNeeded()
  51 |    await page.screenshot({path:info.outputPath(`service-create-${mode}-pending.png`)})
  52 |    permitRead=true
  53 |    await drawer.getByRole('button',{name:mode==='read_failure'?'Consultar el alta registrada':'Reintentar la misma acción',exact:true}).click()
  54 |    if(mode==='read_failure')await expect.poll(()=>reads).toBe(2)
  55 |    else{await expect.poll(()=>commands.length).toBe(2);expect(commands[1]).toEqual(commands[0])}
  56 |   }
  57 |   await expect(drawer).toHaveCount(0)
  58 |   const card=page.locator(`article[data-portfolio-id="${service}"]`)
  59 |   await expect(card.getByRole('heading',{name:child.display_name,exact:true})).toBeVisible()
  60 |   expect(commands.map(c=>c.operation)).toEqual(Array(mode==='success'||mode==='read_failure'?1:2).fill('service.create_manual'))
  61 |   expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  62 |   await card.scrollIntoViewIfNeeded();await page.screenshot({path:info.outputPath(`service-create-${mode}-current.png`)})
  63 |  }finally{await page.close()}
  64 | })
  65 | 
```
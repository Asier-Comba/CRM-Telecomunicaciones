# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: inbox-readback.spec.ts >> inbox confirmed receipt requires coherent stale readback
- Location: tools\oier_commercial_qa\inbox-readback.spec.ts:7:99

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('button', { name: 'Comprobar la misma acción', exact: true })
Expected: enabled
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" with timeout 4000ms
  - waiting for getByRole('button', { name: 'Comprobar la misma acción', exact: true })

```

```yaml
- banner: CRM synthetic inbox contact pagination fixture
- main:
  - button "Cambiar empresa sintética"
  - button "Cambiar actor sintético"
  - button "Cambiar a lector sintético"
  - text: Empresa sintética A
  - strong: Integración local
  - text: · Datos sintéticos de prueba · Cambios guardados en la base local
  - heading "Inbox interno" [level=1]
  - paragraph: Notas compartidas, seguimiento y contexto del cliente. No envía mensajes externos.
  - button "Nueva conversación"
  - text: 0 conversaciones sin leer Canal interno · Integraciones externas sin configurar
  - button "Actualizar Inbox"
  - status: Cambio guardado. La conversación se ha actualizado.
  - region "Conversaciones":
    - text: Estado de conversaciones
    - combobox "Estado de conversaciones":
      - option "Abiertas" [selected]
      - option "Cerradas"
      - option "Archivadas"
    - list:
      - listitem:
        - button "Conversación interna 1 11 oct 2026, 11:00 · 0 notas Sin cliente vinculado":
          - text: Conversación interna 1
          - paragraph: 11 oct 2026, 11:00 · 0 notas
          - paragraph: Sin cliente vinculado
    - button "Anterior" [disabled]
    - text: "1"
    - button "Siguiente" [disabled]
  - region "Hilo interno":
    - heading "Notas internas" [level=2]
    - text: Abiertas
    - button "Marcar no leído"
    - list
    - button "Notas anteriores" [disabled]
    - text: Página 1 · Hasta 20 notas
    - button "Más notas" [disabled]
    - text: Nueva nota interna
    - textbox "Nueva nota interna"
    - text: 0/2000 · Solo el equipo autorizado
    - button "Guardar nota" [disabled]
  - complementary "Contexto de conversación":
    - heading "Contexto" [level=2]
    - paragraph: Nota manual interna · 11 oct 2026, 11:00
    - paragraph: Sin empresa vinculada
    - paragraph: "Responsable: Sin asignar"
    - text: Asignar responsable
    - combobox "Asignar responsable de conversación":
      - option "Sin asignar" [selected]
    - heading "Cambiar vínculo de cliente" [level=3]
    - text: Buscar empresa
    - textbox "Buscar empresa para agenda":
      - /placeholder: Escribe al menos 2 caracteres
    - text: Cliente vinculado
    - combobox "Cliente vinculado":
      - option "Sin cliente" [selected]
    - paragraph: Hasta cinco empresas autorizadas por búsqueda.
    - text: Contacto
    - combobox "Contacto de conversación" [disabled]:
      - option "Sin contacto" [selected]
    - button "Guardar vínculo"
    - paragraph: Sin selección elimina el vínculo actual.
    - button "Cerrar conversación"
    - button "Archivar conversación"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startInboxContactPaginationFixture} from '../../tests/e2e-preview/fixtures/inbox-contact-pagination-server.cjs'
  3  | const id='10000000-0000-4000-8000-000000000001',body='Nota sintética pendiente de consulta coherente'
  4  | let fixture:Awaited<ReturnType<typeof startInboxContactPaginationFixture>>
  5  | test.beforeAll(async()=>{fixture=await startInboxContactPaginationFixture()})
  6  | test.afterAll(async()=>{await fixture?.close()})
  7  | for(const mode of ['stale','wrong_status','exact','newer','mark_read','mark_unread'] as const)test(`inbox confirmed receipt requires coherent ${mode} readback`,async({page},info)=>{
  8  |  const commands:{operation:string;input:Record<string,unknown>}[]=[],errors:string[]=[]
  9  |  const readMarker=mode.startsWith('mark_')
  10 |  let applied=false,corrected=false,readbacks=0
  11 |  const record=()=>({id,version:!applied||readMarker||!corrected&&mode==='stale'?1:mode==='newer'?3:2,status:applied&&(mode==='newer'||!corrected&&mode==='wrong_status')?'closed':'open',channel:'internal',source:'manual_internal',assigned_user_id:null,customer_id:null,contact_id:null,last_seq:applied&&!readMarker&&(!['stale'].includes(mode)||corrected)?1:0,created_at:'2026-10-11T09:00:00Z',updated_at:'2026-10-11T09:00:00Z',read_version:applied&&readMarker?1:0,unread:mode==='mark_read'?!applied:mode==='mark_unread'?applied:false})
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const q=route.request().postDataJSON();let data:unknown
  15 |   if(['message.add_internal_note','conversation.mark_read','conversation.mark_unread'].includes(q.operation)){
  16 |    commands.push(q);applied=true
  17 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'inbox.v1',operation:q.operation,command_id:q.input.command_id,id,version:readMarker?1:2,status:mode==='mark_read'?'read':mode==='mark_unread'?'unread':'open'}}});return
  18 |   }
  19 |   if(q.operation==='inbox.list')data={contract_version:'inbox.v1',operation:q.operation,items:[record()],next_id:null}
  20 |   else if(q.operation==='inbox.get_thread'){
  21 |    if(applied)readbacks++
  22 |    const current=record()
  23 |    data={contract_version:'inbox.v1',operation:q.operation,conversation:current,messages:current.last_seq?[{id:'30000000-0000-4000-8000-000000000001',seq:1,kind:'internal_note',body,actor_user_id:'40000000-0000-4000-8000-000000000001',created_at:'2026-10-11T09:00:00Z'}]:[],next_seq:null,provider_status:'not_configured'}
  24 |   }else if(q.operation==='inbox.unread_summary')data={contract_version:'inbox.v1',operation:q.operation,unread_count:0}
  25 |   else{await route.fulfill({status:400,json:{ok:false,error:'validation'}});return}
  26 |   await route.fulfill({json:{ok:true,data}})
  27 |  })
  28 |  try{
  29 |   await page.goto(fixture.url)
  30 |   const field=page.getByRole('textbox',{name:'Nueva nota interna',exact:true})
  31 |   await expect(field).toBeVisible()
  32 |   if(readMarker)await page.getByRole('button',{name:mode==='mark_read'?'Marcar leído':'Marcar no leído',exact:true}).click()
  33 |   else{await field.fill(body);await page.getByRole('button',{name:'Guardar nota',exact:true}).click()}
  34 |   await expect.poll(()=>readbacks>0).toBe(true)
  35 |   if(['stale','wrong_status'].includes(mode)){
  36 |    await info.attach('readback-observation',{body:JSON.stringify({mode,commands,readbacks}),contentType:'application/json'})
  37 |    const retry=page.getByRole('button',{name:'Comprobar la misma acción',exact:true})
> 38 |    await expect(retry).toBeEnabled();await expect(field).toBeDisabled();await expect(field).toHaveValue(body)
     |                        ^ Error: expect(locator).toBeEnabled() failed
  39 |    await expect(page.getByRole('status').filter({hasText:'Cambio guardado. La conversación se ha actualizado.'})).toHaveCount(0)
  40 |    await page.screenshot({path:info.outputPath(`inbox-${mode}-registered.png`)})
  41 |    corrected=true;await retry.click()
  42 |   }
  43 |   await expect(page.getByRole('status').filter({hasText:'Cambio guardado. La conversación se ha actualizado.'})).toBeVisible()
  44 |   if(readMarker)await expect(page.getByRole('button',{name:mode==='mark_read'?'Marcar no leído':'Marcar leído',exact:true})).toBeEnabled()
  45 |   else await expect(page.getByText(body,{exact:true})).toBeVisible()
  46 |   expect(commands).toHaveLength(1)
  47 |   expect(commands[0].operation).toBe(readMarker?'conversation.'+mode:'message.add_internal_note')
  48 |   expect(commands[0].input.expected_version).toBe(readMarker?0:1)
  49 |   expect(errors).toEqual([])
  50 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  51 |   await page.screenshot({path:info.outputPath(`inbox-${mode}-coherent.png`)})
  52 |  }finally{await page.close()}
  53 | })
  54 | 
```
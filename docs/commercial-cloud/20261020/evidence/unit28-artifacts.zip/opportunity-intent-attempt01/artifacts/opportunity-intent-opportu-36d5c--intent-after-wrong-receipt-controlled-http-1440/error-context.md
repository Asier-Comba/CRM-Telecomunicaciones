# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: opportunity-intent.spec.ts >> opportunity create retains frozen intent after wrong_receipt
- Location: tools\oier_commercial_qa\opportunity-intent.spec.ts:8:108

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  getByRole('dialog', { name: 'Nueva oportunidad', exact: true }).getByRole('textbox', { name: 'Título comercial', exact: true })
Expected: disabled
Received: enabled
Timeout:  4000ms

Call log:
  - Expect "toBeDisabled" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Nueva oportunidad', exact: true }).getByRole('textbox', { name: 'Título comercial', exact: true })
    12 × locator resolved to <input required="" maxlength="200" value="Instalación sintética con revisión comercial" class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 disabled:opacity-50 mt-1 w-full"/>
       - unexpected value "enabled"

```

```yaml
- textbox "Título comercial": Instalación sintética con revisión comercial
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startPipelineCurrentFixture} from '../../tests/e2e-preview/fixtures/pipeline-current-server.cjs'
  3  | const customer='10000000-0000-4000-8000-000000000001',stage='20000000-0000-4000-8000-000000000001',id='30000000-0000-4000-8000-000000000001'
  4  | const title='Instalación sintética con revisión comercial',company='Empresa sintética de oportunidad'
  5  | let fixture:Awaited<ReturnType<typeof startPipelineCurrentFixture>>
  6  | test.beforeAll(async()=>{fixture=await startPipelineCurrentFixture()})
  7  | test.afterAll(async()=>{await fixture?.close()})
  8  | for(const mode of ['transport','malformed','wrong_receipt','read_failure','denied','success'] as const)test(`opportunity create retains frozen intent after ${mode}`,async({page},info)=>{
  9  |  const commands:{operation:string;input:Record<string,unknown>}[]=[],effects=new Set<string>(),errors:string[]=[]
  10 |  let reads=0
  11 |  page.on('pageerror',e=>errors.push(e.message))
  12 |  await page.route('**/api/**',async route=>{
  13 |   const q=route.request().postDataJSON();let data:unknown
  14 |   if(route.request().url().endsWith('/commands')){
  15 |    commands.push(q)
  16 |    if(q.operation!=='opportunity.create'||mode==='denied'){await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  17 |    effects.add(q.input.command_id)
  18 |    if(commands.length===1&&mode==='transport'){await route.abort('failed');return}
  19 |    if(commands.length===1&&mode==='malformed'){await route.fulfill({contentType:'application/json',body:'{'});return}
  20 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'product.v1',operation:q.operation,command_id:commands.length===1&&mode==='wrong_receipt'?'70000000-0000-4000-8000-000000000009':q.input.command_id,id,version:1,status:'open'}}});return
  21 |   }
  22 |   if(q.operation==='opportunity.stages')data={contract_version:'product.v1',items:[{id:stage,code:'new',display_name:'Nueva sintética',position:0,outcome:null,status:'active'}],next_id:null}
  23 |   else if(q.operation==='global.search')data={contract_version:'product.v1',items:[{kind:'customer',id:customer,customer_id:customer,label:company,status:'active'}]}
  24 |   else if(q.operation==='work.get'){
  25 |    reads++
  26 |    if(mode==='read_failure'&&reads===1){await route.fulfill({status:500,json:{ok:false,error:'internal_safe'}});return}
  27 |    const input=commands[0]?.input
  28 |    data={contract_version:'product.v1',kind:'opportunity',record:{id,version:1,title:input?.title,status:'open',customer_id:customer,stage_id:stage,owner_user_id:null,amount_minor:input?.amount_minor,currency:input?.currency,next_follow_up_at:null,expected_close_date:input?.expected_close_date,next_action:input?.next_action,source:'manual',links:[],history:[],history_partial:false}}
  29 |   }else{await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  30 |   await route.fulfill({json:{ok:true,data}})
  31 |  })
  32 |  try{
  33 |   await page.goto(fixture.url)
  34 |   await page.getByRole('button',{name:'Nueva oportunidad',exact:true}).click()
  35 |   const dialog=page.getByRole('dialog',{name:'Nueva oportunidad',exact:true}),field=dialog.getByRole('textbox',{name:'Título comercial',exact:true})
  36 |   await field.fill(title)
  37 |   await dialog.getByRole('textbox',{name:'Buscar empresa para agenda',exact:true}).fill('Empresa')
  38 |   const client=dialog.getByRole('combobox',{name:'Cliente vinculado',exact:true})
  39 |   await expect(client.locator('option',{hasText:company})).toHaveCount(1);await client.selectOption(customer)
  40 |   await dialog.getByRole('textbox',{name:'Importe',exact:true}).fill('1250,50')
  41 |   await dialog.getByLabel('Cierre previsto',{exact:true}).fill('2026-11-20')
  42 |   await dialog.getByRole('textbox',{name:'Próxima acción',exact:true}).fill('Revisar propuesta sintética')
  43 |   await dialog.getByRole('button',{name:'Guardar oportunidad',exact:true}).click()
  44 |   await expect.poll(()=>commands.length).toBe(1)
  45 |   if(!['success','denied'].includes(mode)){
  46 |    await expect(dialog.getByRole('alert')).toBeVisible()
> 47 |    await expect(field).toBeDisabled();await expect(field).toHaveValue(title);await expect(client).toHaveValue(customer)
     |                        ^ Error: expect(locator).toBeDisabled() failed
  48 |    await expect(dialog.getByRole('textbox',{name:'Importe',exact:true})).toHaveValue('1250.50')
  49 |    await expect(dialog.getByLabel('Cierre previsto',{exact:true})).toHaveValue('2026-11-20')
  50 |    await expect(dialog.getByRole('textbox',{name:'Próxima acción',exact:true})).toHaveValue('Revisar propuesta sintética')
  51 |    await dialog.getByRole('button',{name:'Cerrar panel',exact:true}).click({force:true});await expect(dialog).toBeVisible()
  52 |    await page.keyboard.press('Escape');await expect(dialog).toBeVisible()
  53 |    await expect(dialog.getByRole('combobox',{name:'Etapa comercial',exact:true})).toBeDisabled()
  54 |    await page.screenshot({path:info.outputPath(`opportunity-${mode}-pending.png`)})
  55 |    const retry=dialog.getByRole('button',{name:mode==='read_failure'?'Consultar la oportunidad guardada':'Reintentar la misma acción',exact:true})
  56 |    await retry.click()
  57 |    if(mode==='read_failure'){await expect.poll(()=>reads).toBe(2);expect(commands).toHaveLength(1)}
  58 |    else{await expect.poll(()=>commands.length).toBe(2);expect(commands[1]).toEqual(commands[0])}
  59 |   }else if(mode==='denied'){
  60 |    await expect(dialog.getByRole('alert')).toBeVisible();await expect(field).toBeEnabled()
  61 |    expect(effects.size).toBe(0);await dialog.getByRole('button',{name:'Cerrar panel',exact:true}).click();await expect(dialog).toHaveCount(0)
  62 |   }
  63 |   if(mode!=='denied'){
  64 |    await expect(dialog).toHaveCount(0)
  65 |    await expect(page.locator(`[data-opportunity-id="${id}"]`)).toContainText(title)
  66 |    expect(effects.size).toBe(1)
  67 |   }
  68 |   expect(commands.every(q=>q.operation==='opportunity.create')).toBe(true)
  69 |   expect(commands[0].input).toMatchObject({title,customer_id:customer,stage_id:stage,amount_minor:125050,currency:'EUR',expected_close_date:'2026-11-20',next_action:'Revisar propuesta sintética'})
  70 |   expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  71 |   await page.screenshot({path:info.outputPath(`opportunity-${mode}-result.png`)})
  72 |  }finally{await page.close()}
  73 | })
  74 | 
```
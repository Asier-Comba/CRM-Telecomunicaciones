# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portability-readback.spec.ts >> portability cancellation keeps coherent wrong_status readback
- Location: tools\oier_commercial_qa\portability-readback.spec.ts:8:88

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('button', { name: 'Actualizar lectura', exact: true })
Expected: enabled
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" with timeout 4000ms
  - waiting for getByRole('button', { name: 'Actualizar lectura', exact: true })

```

```yaml
- banner: CRM synthetic telecom resource fixture
- main:
  - button "Cambiar empresa sintética"
  - button "Cambiar actor sintético"
  - button "Cambiar a lector sintético"
  - text: Empresa sintética A
  - navigation "Recurso sintético seleccionado":
    - button "Seleccionar recurso A"
    - button "Seleccionar recurso B"
    - button "Seleccionar recurso C"
    - button "Seleccionar recurso D"
    - status "Referencia de recurso actual": 40000000-0000-4000-8000-000000000001
  - heading "Portabilidad · ••••123" [level=1]
  - text: Borrador Entrada
  - link "Cliente sintético de portabilidad":
    - /url: /clients/10000000-0000-4000-8000-000000000001
  - text: Sin responsable
  - paragraph: Operador origen sintético → Operador destino sintético
  - term: Solicitud
  - definition: 11 oct 2026
  - term: Presentada
  - definition: Sin fecha
  - term: Programada
  - definition: Sin fecha
  - term: En curso
  - definition: Sin fecha
  - term: Completada
  - definition: Sin fecha
  - term: Cerrada
  - definition: Sin fecha
  - navigation "Relaciones de portabilidad":
    - link "Abrir cliente":
      - /url: /clients/10000000-0000-4000-8000-000000000001
    - link "Abrir servicio":
      - /url: /services/70000000-0000-4000-8000-000000000001
    - link "Abrir Línea sintética sin cambio de estado":
      - /url: /portfolio?kind=line&id=50000000-0000-4000-8000-000000000001
    - link "Abrir contrato":
      - /url: /portfolio?kind=contract&id=60000000-0000-4000-8000-000000000001
  - paragraph: Registro interno de hechos confirmados. No envía solicitudes ni ejecuta cambios con el operador.
  - heading "Borrador de portabilidad" [level=2]
  - text: Operador
  - combobox "Operador origen de portabilidad":
    - option "Todos los operadores"
    - option "Operador origen sintético" [selected]
    - option "Operador destino sintético"
  - text: Operador
  - combobox "Operador destino de portabilidad":
    - option "Todos los operadores"
    - option "Operador origen sintético"
    - option "Operador destino sintético" [selected]
  - text: Fecha de solicitud
  - textbox "Fecha de solicitud de portabilidad": 2026-10-11
  - button "Revisar borrador de portabilidad"
  - heading "Responsable de portabilidad" [level=2]
  - text: Responsable
  - combobox "Responsable autorizado":
    - option "Sin responsable" [selected]
  - button "Revisar responsable de portabilidad"
  - heading "Seguimiento de portabilidad" [level=2]
  - text: Fecha efectiva
  - textbox "Fecha efectiva de portabilidad": 2026-10-20
  - text: Nuevo estado
  - combobox "Nuevo estado de portabilidad":
    - option "Solicitada" [selected]
    - option "Cancelado"
  - button "Revisar seguimiento de portabilidad"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startTelecomResourceFixture} from '../../tests/e2e-preview/fixtures/telecom-resource-server.cjs'
  3  | const id='40000000-0000-4000-8000-000000000001',customer='10000000-0000-4000-8000-000000000001',donor='20000000-0000-4000-8000-000000000001',operator='20000000-0000-4000-8000-000000000002'
  4  | const line='50000000-0000-4000-8000-000000000001',contract='60000000-0000-4000-8000-000000000001',service='70000000-0000-4000-8000-000000000001',number='80000000-0000-4000-8000-000000000001'
  5  | let fixture:Awaited<ReturnType<typeof startTelecomResourceFixture>>
  6  | test.beforeAll(async()=>{fixture=await startTelecomResourceFixture()})
  7  | test.afterAll(async()=>{await fixture?.close()})
  8  | for(const mode of ['stale','wrong_status','wrong_source','exact','newer'] as const)test(`portability cancellation keeps coherent ${mode} readback`,async({page},info)=>{
  9  |  const commands:{operation:string;input:Record<string,unknown>}[]=[],errors:string[]=[]
  10 |  let applied=false,corrected=false,readbacks=0
  11 |  const initial={id,version:1,customer_id:customer,contract_id:contract,service_id:service,line_id:line,number_identifier_id:number,masked_display:'••••123',direction:'inbound',donor_operator_id:donor,target_operator_id:operator,requested_on:'2026-10-11',submitted_on:null,scheduled_on:null,started_on:null,completed_on:null,closed_on:null,status:'draft',reason_code:null,owner_user_id:null,source:'manual',created_at:'2026-10-11T12:00:00Z',updated_at:'2026-10-11T12:00:00Z'}
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const q=route.request().postDataJSON();let data:unknown
  15 |   if(['portability.create','portability.update_draft','portability.assign','portability.transition','portability.complete'].includes(q.operation)){
  16 |    commands.push(q)
  17 |    if(q.operation!=='portability.transition'){await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  18 |    applied=true;data={contract_version:'portability.v1',operation:q.operation,command_id:q.input.command_id,id,version:2,status:'cancelled',source:'manual',line_effect:null}
  19 |   }else if(q.operation==='portability.get'){
  20 |    if(applied)readbacks++
  21 |    const old=!applied||!corrected&&mode==='stale',cancelled=corrected||mode!=='wrong_status'
  22 |    data={contract_version:'portability.v1',operation:q.operation,record:old?initial:{...initial,version:mode==='newer'?3:2,status:cancelled?'cancelled':'draft',source:!corrected&&mode==='wrong_source'?'integration':'manual',closed_on:cancelled?'2026-10-20':null,reason_code:cancelled?'customer_withdrew':null,updated_at:'2026-10-20T06:00:00Z'}}
  23 |   }else if(q.operation==='customer.list')data={contract_version:'telecom.collections.v1',operation:q.operation,items:[{id:customer,version:1,display_name:'Cliente sintético de portabilidad',account_kind:'legal_entity',lifecycle:'customer',status:'active',source:'manual',assigned_user_id:null}],next_id:null}
  24 |   else if(q.operation==='operator.list')data={contract_version:'telecom.collections.v1',operation:q.operation,items:[donor,operator].map((key,i)=>({id:key,version:1,code:'oier_'+i,display_name:i?'Operador destino sintético':'Operador origen sintético',status:'active',source:'manual'})),next_id:null}
  25 |   else if(q.operation==='operator.get')data={contract_version:'telecom.collections.v1',operation:q.operation,record:{id:q.input.id,version:1,code:q.input.id===donor?'oier_0':'oier_1',display_name:q.input.id===donor?'Operador origen sintético':'Operador destino sintético',status:'active',source:'manual'}}
  26 |   else if(q.operation==='assignee.list')data={contract_version:'telecom.collections.v1',operation:q.operation,items:[],next_id:null}
  27 |   else if(q.operation==='line.list')data={contract_version:'telecom.collections.v1',operation:q.operation,items:[{id:line,version:1,service_id:service,customer_id:customer,contract_id:contract,operator_id:operator,plan_version_id:null,display_name:'Línea sintética sin cambio de estado',status:'active',source:'manual',activated_on:'2026-10-01',ended_on:null,service_kind:'mobile',masked_msisdn:'••••123',sim_id:null,sim_kind:null,sim_status:null,masked_iccid:null,masked_eid:null,portability_id:id,portability_status:applied?'cancelled':'draft',open_commitment_count:0,next_commitment_ends_on:null}],next_id:null}
  28 |   else if(q.operation==='portfolio.get'){
  29 |    const base={id:q.input.id,version:1,status:'active',source:'manual',customer_id:customer,operator_id:operator,plan_version_id:null}
  30 |    data={contract_version:'portfolio.v1',kind:q.input.kind,record:q.input.kind==='contract'?{...base,start_date:'2026-10-01',signed_date:'2026-10-01',end_date:null,assigned_user_id:null}:{...base,contract_id:contract,service_kind:'mobile',display_name:'Servicio sintético',activated_on:'2026-10-01',ended_on:null,status_effective_on:'2026-10-01'}}
  31 |   }else{await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  32 |   await route.fulfill({json:{ok:true,data}})
  33 |  })
  34 |  try{
  35 |   await page.goto(fixture.url+'/?kind=portability')
  36 |   const review=page.getByRole('button',{name:'Revisar seguimiento de portabilidad',exact:true})
  37 |   await expect(review).toBeVisible()
  38 |   await page.getByRole('combobox',{name:'Nuevo estado de portabilidad',exact:true}).selectOption('cancelled')
  39 |   await page.getByLabel('Fecha efectiva de portabilidad',{exact:true}).fill('2026-10-20')
  40 |   await page.getByRole('combobox',{name:'Motivo de cierre de portabilidad',exact:true}).selectOption('customer_withdrew')
  41 |   await review.click()
  42 |   const confirm=page.getByRole('dialog',{name:'Confirmar cambio de portabilidad',exact:true})
  43 |   await confirm.getByRole('button',{name:'Confirmar cambio',exact:true}).click()
  44 |   await expect.poll(()=>readbacks>0).toBe(true)
  45 |   if(['stale','wrong_status','wrong_source'].includes(mode)){
  46 |    const retry=page.getByRole('button',{name:'Actualizar lectura',exact:true})
  47 |    await info.attach('confirmed-readback-observation',{body:JSON.stringify({mode,commands,readbacks,reviewCount:await review.count(),retryCount:await retry.count()}),contentType:'application/json'})
> 48 |    await expect(retry).toBeEnabled();await expect(review).toBeDisabled();await expect(confirm).toHaveCount(0)
     |                        ^ Error: expect(locator).toBeEnabled() failed
  49 |    await expect(page.getByRole('status').filter({hasText:'Cambio registrado. Reintentar solo actualiza la lectura.'})).toBeVisible()
  50 |    await retry.scrollIntoViewIfNeeded();await page.screenshot({path:info.outputPath(`portability-${mode}-registered.png`)})
  51 |    corrected=true;await retry.click()
  52 |   }
  53 |   await expect(page.getByText('Cancelado',{exact:true})).toBeVisible();await expect(review).toHaveCount(0)
  54 |   expect(commands).toHaveLength(1);expect(commands[0].operation).toBe('portability.transition')
  55 |   expect(commands[0].input).toMatchObject({id,expected_version:1,status:'cancelled',effective_on:'2026-10-20',reason_code:'customer_withdrew',evidence_source:'manual'})
  56 |   expect(commands[0].input).not.toHaveProperty('line_action');expect(commands[0].input).not.toHaveProperty('expected_line_version')
  57 |   expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  58 |   await page.locator('#main-content').evaluate(el=>{el.scrollTop=0})
  59 |   await page.screenshot({path:info.outputPath(`portability-${mode}-coherent.png`)})
  60 |  }finally{await page.close()}
  61 | })
  62 | 
```
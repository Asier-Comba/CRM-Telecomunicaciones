# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: document-intent.spec.ts >> document archive preserves exact intent after wrong_receipt
- Location: work\oier-documents-unit18-qa\document-intent.spec.ts:7:147

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  getByRole('dialog', { name: 'Archivar documento', exact: true }).getByRole('button', { name: 'Cancelar', exact: true })
Expected: disabled
Received: enabled
Timeout:  4000ms

Call log:
  - Expect "toBeDisabled" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Archivar documento', exact: true }).getByRole('button', { name: 'Cancelar', exact: true })
    12 × locator resolved to <button class="inline-flex items-center justify-center rounded-lg font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-white text-gray-700 border border-gray-200 shadow-sm hover:border-gray-300 hover:bg-gray-50 hover:text-gray-900 h-8 px-3 text-xs gap-1.5">Cancelar</button>
       - unexpected value "enabled"

```

```yaml
- button "Cancelar"
```

# Test source

```ts
  1  | import {expect,test} from '../crm-oier-commercial-20261020/node_modules/@playwright/test/index.mjs'
  2  | import {startDocumentFixture} from './documents-server.cjs'
  3  | const id='20000000-0000-4000-8000-000000000001',customer='10000000-0000-4000-8000-000000000001'
  4  | let fixture:Awaited<ReturnType<typeof startDocumentFixture>>
  5  | test.beforeAll(async()=>{fixture=await startDocumentFixture()})
  6  | test.afterAll(async()=>{await fixture?.close()})
  7  | for(const operation of ['archive','restore'] as const)for(const mode of ['transport','malformed','wrong_receipt','denied','success'] as const)test(`document ${operation} preserves exact intent after ${mode}`,async({page},info)=>{
  8  |  const commands:{operation:string;input:{command_id:string}}[]=[],errors:string[]=[]
  9  |  let status=operation==='archive'?'active':'archived',version=1
  10 |  page.on('pageerror',e=>errors.push(e.message))
  11 |  await page.route('**/api/**',async route=>{
  12 |   const q=route.request().postDataJSON()
  13 |   if(route.request().url().endsWith('/commands')){
  14 |    commands.push(q)
  15 |    if(commands.length===1){
  16 |     if(mode==='transport'){await route.abort('failed');return}
  17 |     if(mode==='malformed'){await route.fulfill({status:200,contentType:'application/json',body:'{'});return}
  18 |     if(mode==='denied'){await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  19 |    }
  20 |    status=operation==='archive'?'archived':'active';version=2
  21 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'document.v1',operation:q.operation,command_id:commands.length===1&&mode==='wrong_receipt'?'70000000-0000-4000-8000-000000000009':q.input.command_id,id,version,status}}});return
  22 |   }
  23 |   if(q.operation==='document.list'){
  24 |    const row={id,version,status,document_kind:'contract',media_type:'application/pdf',size_bytes:100,target:{kind:'customer',id:customer}}
  25 |    await route.fulfill({json:{ok:true,data:{contract_version:'document.v1',operation:q.operation,items:status===(q.input.status??'active')?[row]:[],next_id:null}}});return
  26 |   }
  27 |   await route.fulfill({status:403,json:{ok:false,error:'access_denied'}})
  28 |  })
  29 |  try{
  30 |   await page.goto(fixture.url)
  31 |   if(operation==='restore')await page.getByRole('combobox',{name:'Estado de documentos',exact:true}).selectOption('archived')
  32 |   const label=operation==='archive'?'Archivar documento':'Restaurar documento'
  33 |   await page.getByRole('button',{name:label,exact:true}).click()
  34 |   const confirm=page.getByRole('dialog',{name:label,exact:true})
  35 |   await confirm.getByRole('button',{name:'Confirmar',exact:true}).click()
  36 |   await expect.poll(()=>commands.length).toBe(1)
  37 |   if(mode==='denied'){
  38 |    await expect(confirm.getByRole('alert')).toBeVisible()
  39 |    await expect(confirm.getByRole('button',{name:'Cancelar',exact:true})).toBeEnabled()
  40 |    await confirm.getByRole('button',{name:'Cancelar',exact:true}).click();await expect(confirm).toHaveCount(0)
  41 |   }else if(mode!=='success'){
  42 |    await expect(confirm.getByRole('alert')).toBeVisible()
  43 |    await info.attach('document-intent-observation',{body:JSON.stringify({operation,mode,commands}),contentType:'application/json'})
> 44 |    await expect(confirm.getByRole('button',{name:'Cancelar',exact:true})).toBeDisabled()
     |                                                                           ^ Error: expect(locator).toBeDisabled() failed
  45 |    await expect(confirm.getByRole('button',{name:'Cerrar',exact:true})).toBeDisabled()
  46 |    await page.keyboard.press('Escape');await expect(confirm).toBeVisible()
  47 |    await page.screenshot({path:info.outputPath(`document-${operation}-${mode}-unknown.png`)})
  48 |    await confirm.getByRole('button',{name:'Reintentar la misma acción',exact:true}).click()
  49 |    await expect(confirm).toHaveCount(0);expect(commands).toHaveLength(2);expect(commands[1]).toEqual(commands[0])
  50 |   }else await expect(confirm).toHaveCount(0)
  51 |   expect(commands.every(c=>c.operation===`document.${operation}`)).toBe(true);expect(errors).toEqual([])
  52 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  53 |  }finally{await page.close()}
  54 | })
  55 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: document-intent.spec.ts >> document archive preserves exact intent after transport
- Location: work\oier-documents-unit18-qa\document-intent.spec.ts:7:147

# Error details

```
Error: Cannot find package 'next' imported from C:\Users\oier.dunabeitia\Documents\Codex\2026-10-08\files-pasted-by-the-user-crm\work\oier-documents-unit18-qa\documents-server.cjs
```

# Test source

```ts
  1  | const { readFile, mkdtemp, rm } = process.getBuiltinModule('node:fs/promises')
  2  | const { createServer } = process.getBuiltinModule('node:http')
  3  | const { tmpdir } = process.getBuiltinModule('node:os')
  4  | const { resolve, sep } = process.getBuiltinModule('node:path')
  5  | const root = resolve(__dirname, '../crm-oier-commercial-20261020')
  6  | let assets
  7  | async function build() {
  8  |  if (assets) return assets
  9  |  assets = (async () => {
> 10 |   const webpackModule=await import('next/dist/compiled/webpack/webpack.js')
     |                       ^ Error: Cannot find package 'next' imported from C:\Users\oier.dunabeitia\Documents\Codex\2026-10-08\files-pasted-by-the-user-crm\work\oier-documents-unit18-qa\documents-server.cjs
  11 |   const {webpack}=webpackModule.default ?? webpackModule
  12 |   const {compile}=await import('@tailwindcss/node'),{Scanner}=await import('@tailwindcss/oxide')
  13 |   const output = await mkdtemp(resolve(tmpdir(), 'crm-oier-document-qa-'))
  14 |   try {
  15 |    await new Promise((accept, reject) => {
  16 |     const compiler = webpack({mode:'development',context:root,target:'web',devtool:false,
  17 |      entry:resolve(__dirname,'documents-entry.tsx'),
  18 |      output:{path:output,filename:'component.js'},optimization:{minimize:false},
  19 |      plugins:[new webpack.DefinePlugin({'process.env':JSON.stringify({NODE_ENV:'development'})}),new webpack.NormalModuleReplacementPlugin(/Provider$/, resource=>{
  20 |       if(resource.context.replaceAll('\\','/').includes('/src/features/product'))resource.request=resolve(root,'tests/e2e-preview/fixtures/pipeline-current-provider.tsx')
  21 |      })],
  22 |      resolve:{modules:[resolve(root,'node_modules'),'node_modules'],extensions:['.tsx','.ts','.js'],alias:{'@/features/product/integration/Provider$':resolve(root,'tests/e2e-preview/fixtures/pipeline-current-provider.tsx'),'@':resolve(root,'src')}},
  23 |      module:{rules:[{test:/\.tsx?$/,exclude:/node_modules/,use:resolve(root,'tests/e2e-preview/fixtures/billing-focus-loader.cjs')}]}})
  24 |     compiler.run((error, stats) => compiler.close(closeError => {
  25 |      if(error || closeError || stats?.hasErrors()) reject(error ?? closeError ?? Error(stats.toString({all:false,errors:true})))
  26 |      else accept()
  27 |     }))
  28 |    })
  29 |    const compiled = await compile(await readFile(resolve(root,'src/app/globals.css'),'utf8'),{base:resolve(root,'src/app'),onDependency(){}})
  30 |    const scanner = new Scanner({sources:[{base:resolve(root,'src'),pattern:'**/*.{ts,tsx}',negated:false}]})
  31 |    return {js:await readFile(resolve(output,'component.js')),css:compiled.build(scanner.scan())}
  32 |   } finally {
  33 |    if(!resolve(output).startsWith(resolve(tmpdir())+sep)||!output.startsWith(resolve(tmpdir(),'crm-oier-document-qa-')))throw Error('OWNED_TEMP_OUTPUT_REQUIRED')
  34 |    await rm(output,{recursive:true,force:true})
  35 |   }
  36 |  })()
  37 |  return assets
  38 | }
  39 | exports.startDocumentFixture = async function startDocumentFixture() {
  40 |  const compiled=await build()
  41 |  const server=createServer((request,response)=>{
  42 |   if(request.url==='/component.js'){response.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8'});response.end(compiled.js);return}
  43 |   if(request.url==='/styles.css'){response.writeHead(200,{'Content-Type':'text/css; charset=utf-8'});response.end(compiled.css);return}
  44 |   if(request.url.split('?')[0]!=='/'){response.writeHead(404);response.end();return}
  45 |   response.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});response.end('<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="/styles.css"><style>body{font-family:Arial,sans-serif}.fixture-header{height:64px;background:white}#main-content{height:calc(100vh - 64px);overflow:auto;padding:24px;overflow-anchor:none}#app{max-width:1200px;margin:auto}</style><header class="fixture-header">CRM synthetic document metadata fixture</header><main id="main-content"><div id="app"></div></main><script src="/component.js"></script>')
  46 |  })
  47 |  await new Promise(accept=>server.listen(0,'127.0.0.1',accept))
  48 |  const address=server.address();if(!address||typeof address==='string')throw Error('FIXTURE_ADDRESS')
  49 |  return {url:`http://127.0.0.1:${address.port}`,async close(){server.closeAllConnections();await new Promise((accept,reject)=>server.close(error=>error?reject(error):accept()))}}
  50 | }
  51 | 
```
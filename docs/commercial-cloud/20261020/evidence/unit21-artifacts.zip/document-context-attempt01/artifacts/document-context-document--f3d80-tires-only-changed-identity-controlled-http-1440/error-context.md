# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: document-context.spec.ts >> document context late retires only changed identity
- Location: tools\oier_commercial_qa\document-context.spec.ts:8:73

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 4000ms exceeded while waiting on the predicate
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startDocumentFixture} from './documents-server.cjs'
  3  | const a='10000000-0000-4000-8000-000000000001',b='10000000-0000-4000-8000-000000000002',contract='60000000-0000-4000-8000-000000000002'
  4  | const docA='20000000-0000-4000-8000-000000000001',docB='20000000-0000-4000-8000-000000000002'
  5  | let fixture:Awaited<ReturnType<typeof startDocumentFixture>>
  6  | test.beforeAll(async()=>{fixture=await startDocumentFixture()})
  7  | test.afterAll(async()=>{await fixture?.close()})
  8  | for(const mode of ['customer','target','late','unchanged'] as const)test(`document context ${mode} retires only changed identity`,async({page},info)=>{
  9  |  const reads:{target_kind:string;target_id:string;status?:string}[]=[],commands:string[]=[],errors:string[]=[]
  10 |  let release!:()=>void,lateResponded=false
  11 |  const held=new Promise<void>(resolve=>{release=resolve})
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const q=route.request().postDataJSON()
  15 |   if(q.operation!=='document.list'){commands.push(q.operation);await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  16 |   reads.push(q.input)
  17 |   if(mode==='late'&&q.input.target_id===a)await held
  18 |   const isA=q.input.target_id===a
  19 |   await route.fulfill({json:{ok:true,data:{contract_version:'document.v1',operation:'document.list',items:[{id:isA?docA:docB,version:1,status:q.input.status??'active',document_kind:isA?'contract':'billing',media_type:'application/pdf',size_bytes:100,target:{kind:q.input.target_kind,id:q.input.target_id}}],next_id:null}}})
  20 |   if(mode==='late'&&isA)lateResponded=true
  21 |  })
  22 |  try{
  23 |   await page.goto(fixture.url+'/?context_controls=1'+(['target','unchanged'].includes(mode)?'&explicit_target=1':''))
  24 |   const old=page.locator(`article[data-document-id="${docA}"]`),current=page.locator(`article[data-document-id="${docB}"]`)
  25 |   await expect.poll(()=>reads.length).toBe(1)
  26 |   if(mode!=='late')await expect(old).toBeVisible()
  27 |   if(mode==='unchanged'){
  28 |    await page.getByRole('combobox',{name:'Estado de documentos',exact:true}).selectOption('archived')
  29 |    await expect(old.getByText('Archivado',{exact:true})).toBeVisible()
  30 |    await page.getByRole('textbox',{name:'Buscar cliente para documentos',exact:true}).fill('Consulta sin enviar')
  31 |    const before=reads.length
  32 |    await page.getByRole('button',{name:'Actualizar contexto documental sintético',exact:true}).click()
  33 |    await expect(page.getByLabel('Versión de contexto documental sintético',{exact:true})).toHaveText('1')
  34 |    await expect(page.getByRole('combobox',{name:'Estado de documentos',exact:true})).toHaveValue('archived')
  35 |    await expect(page.getByRole('textbox',{name:'Buscar cliente para documentos',exact:true})).toHaveValue('Consulta sin enviar')
  36 |    await expect(old).toBeVisible();expect(reads).toHaveLength(before)
  37 |   }else{
  38 |    await page.getByRole('button',{name:'Cambiar contexto documental sintético',exact:true}).click()
> 39 |    await expect.poll(()=>reads.some(r=>r.target_id===(mode==='target'?contract:b))).toBe(true)
     |                                                                                     ^ Error: expect(received).toBe(expected) // Object.is equality
  40 |    await expect(current).toBeVisible();await expect(old).toHaveCount(0)
  41 |    if(mode==='target')await expect(page.getByRole('heading',{name:'Contrato sintético B',exact:true})).toBeVisible()
  42 |    if(mode==='late'){
  43 |     release();await expect.poll(()=>lateResponded).toBe(true)
  44 |     await page.getByRole('button',{name:'Actualizar contexto documental sintético',exact:true}).click()
  45 |     await expect(page.getByLabel('Versión de contexto documental sintético',{exact:true})).toHaveText('1')
  46 |     await expect(current).toBeVisible();await expect(old).toHaveCount(0)
  47 |    }
  48 |    expect(reads.at(-1)).toMatchObject({target_kind:mode==='target'?'contract':'customer',target_id:mode==='target'?contract:b})
  49 |   }
  50 |   expect(commands).toEqual([]);expect(errors).toEqual([])
  51 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  52 |   await page.screenshot({path:info.outputPath(`document-context-${mode}.png`)})
  53 |  }finally{release();await page.close()}
  54 | })
  55 | 
```
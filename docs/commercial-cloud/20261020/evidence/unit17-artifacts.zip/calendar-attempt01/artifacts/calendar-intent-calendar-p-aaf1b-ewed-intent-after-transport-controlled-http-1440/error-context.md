# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: calendar-intent.spec.ts >> calendar preserves the reviewed intent after transport
- Location: tools\oier_commercial_qa\calendar-intent.spec.ts:7:93

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog', { name: 'Detalle de agenda', exact: true })
Expected: visible
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Detalle de agenda', exact: true })

```

```yaml
- banner: CRM synthetic calendar selection fixture
- main:
  - button "Cambiar empresa sintética"
  - button "Cambiar actor sintético"
  - button "Cambiar a lector sintético"
  - text: Empresa sintética A Estado
  - combobox "Estado de agenda":
    - option "Todos los estados" [selected]
    - option "Pendiente"
    - option "En curso"
    - option "Programada"
    - option "Plazo abierto"
    - option "Completada"
    - option "Cancelada"
    - option "Ausencia"
    - option "Descartada"
  - button "Actualizar agenda"
  - text: Página 1 · hasta 100 actividades
  - heading "Calendario y tareas" [level=1]
  - paragraph: Agenda, seguimiento y fechas de tu cartera
  - button "Nueva cita"
  - strong: Integración local
  - text: · Datos sintéticos de prueba · Cambios guardados en la base local
  - complementary "Fecha y filtros del calendario":
    - paragraph: octubre de 2026
    - button "Mes anterior"
    - button "Mes siguiente"
    - text: L M X J V S D
    - button "Ir al 2026-09-28": "28"
    - button "Ir al 2026-09-29": "29"
    - button "Ir al 2026-09-30": "30"
    - button "Ir al 2026-10-01": "1"
    - button "Ir al 2026-10-02": "2"
    - button "Ir al 2026-10-03": "3"
    - button "Ir al 2026-10-04": "4"
    - button "Ir al 2026-10-05": "5"
    - button "Ir al 2026-10-06": "6"
    - button "Ir al 2026-10-07": "7"
    - button "Ir al 2026-10-08": "8"
    - button "Ir al 2026-10-09": "9"
    - button "Ir al 2026-10-10": "10"
    - button "Ir al 2026-10-11": "11"
    - button "Ir al 2026-10-12" [pressed]: "12"
    - button "Ir al 2026-10-13": "13"
    - button "Ir al 2026-10-14": "14"
    - button "Ir al 2026-10-15": "15"
    - button "Ir al 2026-10-16": "16"
    - button "Ir al 2026-10-17": "17"
    - button "Ir al 2026-10-18": "18"
    - button "Ir al 2026-10-19": "19"
    - button "Ir al 2026-10-20": "20"
    - button "Ir al 2026-10-21": "21"
    - button "Ir al 2026-10-22": "22"
    - button "Ir al 2026-10-23": "23"
    - button "Ir al 2026-10-24": "24"
    - button "Ir al 2026-10-25": "25"
    - button "Ir al 2026-10-26": "26"
    - button "Ir al 2026-10-27": "27"
    - button "Ir al 2026-10-28": "28"
    - button "Ir al 2026-10-29": "29"
    - button "Ir al 2026-10-30": "30"
    - button "Ir al 2026-10-31": "31"
    - button "Ir al 2026-11-01": "1"
    - button "Ir al 2026-11-02": "2"
    - button "Ir al 2026-11-03": "3"
    - button "Ir al 2026-11-04": "4"
    - button "Ir al 2026-11-05": "5"
    - button "Ir al 2026-11-06": "6"
    - button "Ir al 2026-11-07": "7"
    - button "Ir al 2026-11-08": "8"
    - text: Comercial
    - combobox "Filtrar calendario por comercial":
      - option "Todos" [selected]
      - option "Sin asignar"
    - text: Tipo
    - combobox "Tipo de evento":
      - option "Todos" [selected]
      - option "Reunión"
      - option "Tarea"
      - option "Renovación"
      - option "Permanencia"
    - paragraph: Reunión
    - paragraph: Tarea
    - paragraph: Renovación
    - paragraph: Permanencia
    - paragraph: Horario Europe/Madrid. Llamadas, instalación y vencimiento de contrato necesitan su proyección de eventos.
  - region "Agenda y vistas del calendario":
    - button "Hoy"
    - button "Periodo anterior"
    - button "Periodo siguiente"
    - heading "12 oct 2026 – 18 oct 2026" [level=2]
    - button "Día"
    - button "Semana" [pressed]
    - button "Mes"
    - button "Agenda"
    - text: Madrid lun 12 mar 13 mié 14 jue 15 vie 16 sáb 17 dom 18 Todo el día 8:00 9:00 10:00 11:00 12:00 13:00 14:00 15:00 16:00 17:00 18:00 19:00
    - button "11:00 · Synthetic reviewed task Sin cliente"
    - text: 1 registros en el periodo · sincronización externa no disponible
  - heading "Próximas citas y fechas" [level=2]
  - button "11:00 · Synthetic reviewed task Sin cliente"
  - navigation "Paginación de agenda":
    - button "Página anterior de agenda" [disabled]
    - button "Siguiente página de agenda" [disabled]
    - paragraph: Todas las actividades con fecha del intervalo consultado.
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startCalendarSelectionFixture} from '../../tests/e2e-preview/fixtures/calendar-selection-server.cjs'
  3  | const id='50000000-0000-4000-8000-000000000002',day='2026-10-12',at=day+'T09:00:00Z'
  4  | let fixture:Awaited<ReturnType<typeof startCalendarSelectionFixture>>
  5  | test.beforeAll(async()=>{fixture=await startCalendarSelectionFixture()})
  6  | test.afterAll(async()=>{await fixture?.close()})
  7  | for(const mode of ['transport','malformed','wrong_receipt','denied','success'] as const)test(`calendar preserves the reviewed intent after ${mode}`,async({page},info)=>{
  8  |  const commands:{operation:string;input:{command_id:string}}[]=[],errors:string[]=[]
  9  |  page.on('pageerror',e=>errors.push(e.message))
  10 |  await page.clock.setFixedTime(new Date('2026-10-11T22:30:00Z'))
  11 |  await page.route('**/api/**',async route=>{
  12 |   const {operation,input}=route.request().postDataJSON()
  13 |   if(route.request().url().endsWith('/commands')){
  14 |    commands.push({operation,input})
  15 |    if(commands.length===1){
  16 |     if(mode==='transport'){await route.abort('failed');return}
  17 |     if(mode==='malformed'){await route.fulfill({status:200,contentType:'application/json',body:'{'});return}
  18 |     if(mode==='denied'){await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  19 |    }
  20 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'product.v1',operation,command_id:commands.length===1&&mode==='wrong_receipt'?'70000000-0000-4000-8000-000000000009':input.command_id,id,version:2,status:'pending'}}});return
  21 |   }
  22 |   if(operation==='calendar.list'){await route.fulfill({json:{ok:true,data:{contract_version:'product.v1',items:[{kind:'task',id,version:1,title:'Synthetic reviewed task',status:'pending',customer_id:null,assigned_user_id:null,at,ends_at:null,all_day:false,date:null}],next:null}}});return}
  23 |   if(operation==='work.get'){await route.fulfill({json:{ok:true,data:{contract_version:'product.v1',kind:'task',record:{id,version:1,status:'pending',customer_id:null,title:'Synthetic reviewed task',due_at:at,priority:'normal',assigned_user_id:null,opportunity_id:null}}}});return}
  24 |   if(['customer.list','assignee.list'].includes(operation)){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation,items:[],next_id:null}}});return}
  25 |   await route.fulfill({status:400,json:{ok:false,error:'validation'}})
  26 |  })
  27 |  try{
  28 |   await page.goto(fixture.url)
  29 |   await page.locator(`[data-calendar-id="${id}"]:visible`).first().click()
  30 |   const drawer=page.getByRole('dialog',{name:'Detalle de agenda',exact:true}),title=drawer.getByLabel('Título',{exact:true})
  31 |   await expect(title).toHaveValue('Synthetic reviewed task')
  32 |   await title.fill('Reviewed task title')
  33 |   await drawer.getByRole('button',{name:'Guardar agenda',exact:true}).click()
  34 |   await expect.poll(()=>commands.length).toBe(1)
  35 |   if(mode==='denied'){
  36 |    await expect(drawer.getByRole('alert')).toBeVisible();await expect(title).toBeEnabled()
  37 |    await drawer.getByRole('button',{name:'Cerrar panel',exact:true}).click();await expect(drawer).toHaveCount(0)
  38 |   }else if(mode!=='success'){
  39 |    await expect(drawer.getByRole('alert')).toBeVisible()
  40 |    await info.attach('unknown-observation',{body:JSON.stringify({mode,commands}),contentType:'application/json'})
  41 |    await expect(title).toBeDisabled()
> 42 |    await drawer.getByRole('button',{name:'Cerrar panel',exact:true}).click();await expect(drawer).toBeVisible()
     |                                                                                                   ^ Error: expect(locator).toBeVisible() failed
  43 |    await page.keyboard.press('Escape');await expect(drawer).toBeVisible()
  44 |    await drawer.getByRole('alert').scrollIntoViewIfNeeded()
  45 |    await page.screenshot({path:info.outputPath(`calendar-${mode}-unknown.png`)})
  46 |    await drawer.getByRole('button',{name:'Reintentar la misma acción',exact:true}).click()
  47 |    await expect(drawer).toHaveCount(0);expect(commands).toHaveLength(2);expect(commands[1]).toEqual(commands[0])
  48 |   }else await expect(drawer).toHaveCount(0)
  49 |   expect(commands.every(c=>c.operation==='task.update')).toBe(true);expect(errors).toEqual([])
  50 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  51 |  }finally{await page.unrouteAll({behavior:'wait'})}
  52 | })
  53 | 
```
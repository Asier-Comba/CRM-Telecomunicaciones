# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: calendar-intent.spec.ts >> calendar preserves the reviewed intent after malformed
- Location: tools\oier_commercial_qa\calendar-intent.spec.ts:7:93

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  getByRole('dialog', { name: 'Detalle de agenda', exact: true }).getByLabel('Título', { exact: true })
Expected: disabled
Received: enabled
Timeout:  4000ms

Call log:
  - Expect "toBeDisabled" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Detalle de agenda', exact: true }).getByLabel('Título', { exact: true })
    12 × locator resolved to <input required="" maxlength="200" value="Reviewed task title" class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 disabled:opacity-50 mt-1 w-full"/>
       - unexpected value "enabled"

```

```yaml
- textbox "Título": Reviewed task title
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startCalendarSelectionFixture} from '../../tests/e2e-preview/fixtures/calendar-selection-server.cjs'
  3  | const id='50000000-0000-4000-8000-000000000002',day='2026-10-12',at=day+'T09:00:00Z'
  4  | let fixture:Awaited<ReturnType<typeof startCalendarSelectionFixture>>
  5  | test.beforeAll(async()=>{fixture=await startCalendarSelectionFixture()})
  6  | test.afterAll(async()=>{await fixture?.close()})
  7  | for(const mode of ['transport','malformed','wrong_receipt','denied','success'] as const)test(`calendar preserves the reviewed intent after ${mode}`,async({page},info)=>{
  8  |  const commands:{operation:string;input:{command_id:string}}[]=[],errors:string[]=[]
  9  |  page.on('pageerror',e=>errors.push(e.message))
  10 |  await page.clock.setFixedTime(new Date('2026-10-11T22:30:00Z'))
  11 |  await page.route('**/api/**',async route=>{
  12 |   const {operation,input}=route.request().postDataJSON()
  13 |   if(route.request().url().endsWith('/commands')){
  14 |    commands.push({operation,input})
  15 |    if(commands.length===1){
  16 |     if(mode==='transport'){await route.abort('failed');return}
  17 |     if(mode==='malformed'){await route.fulfill({status:200,contentType:'application/json',body:'{'});return}
  18 |     if(mode==='denied'){await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  19 |    }
  20 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'product.v1',operation,command_id:commands.length===1&&mode==='wrong_receipt'?'70000000-0000-4000-8000-000000000009':input.command_id,id,version:2,status:'pending'}}});return
  21 |   }
  22 |   if(operation==='calendar.list'){await route.fulfill({json:{ok:true,data:{contract_version:'product.v1',items:[{kind:'task',id,version:1,title:'Synthetic reviewed task',status:'pending',customer_id:null,assigned_user_id:null,at,ends_at:null,all_day:false,date:null}],next:null}}});return}
  23 |   if(operation==='work.get'){await route.fulfill({json:{ok:true,data:{contract_version:'product.v1',kind:'task',record:{id,version:1,status:'pending',customer_id:null,title:'Synthetic reviewed task',due_at:at,priority:'normal',assigned_user_id:null,opportunity_id:null}}}});return}
  24 |   if(['customer.list','assignee.list'].includes(operation)){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation,items:[],next_id:null}}});return}
  25 |   await route.fulfill({status:400,json:{ok:false,error:'validation'}})
  26 |  })
  27 |  try{
  28 |   await page.goto(fixture.url)
  29 |   await page.locator(`[data-calendar-id="${id}"]:visible`).first().click()
  30 |   const drawer=page.getByRole('dialog',{name:'Detalle de agenda',exact:true}),title=drawer.getByLabel('Título',{exact:true})
  31 |   await expect(title).toHaveValue('Synthetic reviewed task')
  32 |   await title.fill('Reviewed task title')
  33 |   await drawer.getByRole('button',{name:'Guardar agenda',exact:true}).click()
  34 |   await expect.poll(()=>commands.length).toBe(1)
  35 |   if(mode==='denied'){
  36 |    await expect(drawer.getByRole('alert')).toBeVisible();await expect(title).toBeEnabled()
  37 |    await drawer.getByRole('button',{name:'Cerrar panel',exact:true}).click();await expect(drawer).toHaveCount(0)
  38 |   }else if(mode!=='success'){
  39 |    await expect(drawer.getByRole('alert')).toBeVisible()
  40 |    await info.attach('unknown-observation',{body:JSON.stringify({mode,commands}),contentType:'application/json'})
> 41 |    await expect(title).toBeDisabled()
     |                        ^ Error: expect(locator).toBeDisabled() failed
  42 |    await drawer.getByRole('button',{name:'Cerrar panel',exact:true}).click();await expect(drawer).toBeVisible()
  43 |    await page.keyboard.press('Escape');await expect(drawer).toBeVisible()
  44 |    await drawer.getByRole('alert').scrollIntoViewIfNeeded()
  45 |    await page.screenshot({path:info.outputPath(`calendar-${mode}-unknown.png`)})
  46 |    await drawer.getByRole('button',{name:'Reintentar la misma acción',exact:true}).click()
  47 |    await expect(drawer).toHaveCount(0);expect(commands).toHaveLength(2);expect(commands[1]).toEqual(commands[0])
  48 |   }else await expect(drawer).toHaveCount(0)
  49 |   expect(commands.every(c=>c.operation==='task.update')).toBe(true);expect(errors).toEqual([])
  50 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  51 |  }finally{await page.unrouteAll({behavior:'wait'})}
  52 | })
  53 | 
```
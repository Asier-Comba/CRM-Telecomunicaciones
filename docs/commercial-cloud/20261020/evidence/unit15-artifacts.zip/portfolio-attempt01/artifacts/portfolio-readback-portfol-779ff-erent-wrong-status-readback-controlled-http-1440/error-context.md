# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: portfolio-readback.spec.ts >> portfolio confirmed command requires coherent wrong_status readback
- Location: tools\oier_commercial_qa\portfolio-readback.spec.ts:9:92

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog', { name: 'Contrato: Contrato', exact: true })
Expected: visible
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Contrato: Contrato', exact: true })

```

```yaml
- banner: CRM synthetic commercial resource fixture
- main:
  - button "Cambiar empresa sintética"
  - button "Cambiar actor sintético"
  - button "Cambiar a lector sintético"
  - text: Empresa sintética A
  - navigation "Contexto de referencia sintética":
    - button "Actualizar contexto sintético"
    - button "Cambiar referencia sintética"
    - status "Versión de contexto sintético": "0"
  - heading "Cartera Telecom" [level=1]
  - paragraph: Activos autorizados y plazos registrados
  - strong: Integración local
  - text: · Datos sintéticos de prueba · Cambios guardados en la base local
  - tablist "Secciones":
    - tab "Contratos" [selected]
    - tab "Servicios"
    - tab "Líneas"
    - tab "SIM/eSIM"
    - tab "Portabilidades"
    - tab "Renovaciones"
    - tab "Permanencias"
    - tab "Incidencias"
    - tab "Equipos"
  - tabpanel "Contratos":
    - button "Registrar contrato manual"
    - heading "Contratos" [level=2]
    - paragraph: Inventario del espacio autorizado · páginas independientes de hasta 20 registros.
    - combobox "Estado de Contratos":
      - option "Todos los estados" [selected]
      - option "Borrador"
      - option "Activo"
      - option "Finalizado"
      - option "Cancelado"
    - button "Actualizar Contratos"
    - paragraph: No hay registros de contratos en esta página.
    - button "Página anterior de Contratos" [disabled]
    - text: Página 1 · 0 registros
    - button "Siguiente página de Contratos" [disabled]
  - heading "Consulta rápida y edición de activos" [level=2]
  - textbox "Consultar cartera local":
    - /placeholder: Buscar empresa o activo
  - button "Consultar cartera"
  - paragraph: Hasta cinco resultados por familia en cada búsqueda. No es el inventario completo. Operadores y tarifas requieren un catálogo de selección autorizado.
  - article:
    - paragraph: "Contrato · Origen: Manual"
    - heading "Contrato" [level=2]
    - text: Borrador
    - button "Ver activo"
    - button "Añadir servicio o plazo"
  - region "Gestión de importaciones":
    - heading "Trabajos de importación" [level=2]
    - paragraph: Consulta y cancelación de trabajos existentes. La carga, validación y aplicación de archivos todavía no están disponibles. El procesamiento sigue bloqueado.
    - combobox "Estado de importaciones":
      - option "Todos los estados" [selected]
      - option "Cargado"
      - option "Asignación de columnas"
      - option "En validación"
      - option "Preparado"
      - option "En aplicación"
      - option "Completado"
      - option "Fallido"
      - option "Cancelado"
    - button "Actualizar importaciones"
    - alert: Revisa los datos introducidos.
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startCommercialResourceFixture} from '../../tests/e2e-preview/fixtures/commercial-resource-server.cjs'
  3  | 
  4  | const id='60000000-0000-4000-8000-000000000001',customer='10000000-0000-4000-8000-000000000001'
  5  | const record={id,version:1,status:'draft',source:'manual',customer_id:customer,operator_id:'20000000-0000-4000-8000-000000000001',plan_version_id:null,start_date:'2026-10-01',signed_date:'2026-10-01',end_date:null,assigned_user_id:null}
  6  | let fixture:Awaited<ReturnType<typeof startCommercialResourceFixture>>
  7  | test.beforeAll(async()=>{fixture=await startCommercialResourceFixture()})
  8  | test.afterAll(async()=>{await fixture?.close()})
  9  | for(const mode of ['stale','wrong_status','wrong_source','confirmed','newer'] as const)test(`portfolio confirmed command requires coherent ${mode} readback`,async({page},info)=>{
  10 |  const commands:{operation:string;input:{command_id:string}}[]=[],errors:string[]=[]
  11 |  let applied=false,corrected=false,readbacks=0
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const body=route.request().postDataJSON(),{operation,input}=body
  15 |   if(route.request().url().endsWith('/commands')){
  16 |    commands.push(body);applied=true
  17 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'portfolio.v1',operation,command_id:input.command_id,id,version:2,status:'active',source:'manual'}}});return
  18 |   }
  19 |   if(operation==='portfolio.get'){
  20 |    if(applied)readbacks++
  21 |    const current=!applied||!corrected&&mode==='stale'?record:{...record,version:mode==='newer'?3:2,status:!corrected&&mode==='wrong_status'?'draft':mode==='newer'?'cancelled':'active',source:!corrected&&mode==='wrong_source'?'integration':'manual'}
  22 |    await route.fulfill({json:{ok:true,data:{contract_version:'portfolio.v1',kind:'contract',record:current}}});return
  23 |   }
  24 |   if(operation==='customer.list'){
  25 |    await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation,items:[{id:customer,version:1,display_name:'Synthetic linked customer',account_kind:'legal_entity',lifecycle:'customer',status:'active',source:'manual',assigned_user_id:null}],next_id:null}}});return
  26 |   }
  27 |   if(['contract.list','service.list','line.list','assignee.list'].includes(operation)){
  28 |    await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation,items:[],next_id:null}}});return
  29 |   }
  30 |   await route.fulfill({status:400,json:{ok:false,error:'validation'}})
  31 |  })
  32 |  try{
  33 |   await page.goto(fixture.url+'/?kind=portfolio&portfolio_reference='+id)
  34 |   const drawer=page.getByRole('dialog',{name:'Contrato: Contrato',exact:true})
  35 |   await expect(drawer).toBeVisible()
  36 |   await drawer.getByRole('button',{name:'Activar contrato',exact:true}).click()
  37 |   const confirm=page.getByRole('dialog',{name:'Confirmar cambio de cartera',exact:true})
  38 |   await confirm.getByRole('button',{name:'Confirmar',exact:true}).click()
  39 |   await expect.poll(()=>readbacks).toBe(1)
  40 |   if(['stale','wrong_status','wrong_source'].includes(mode)){
  41 |    // Observe both outcomes without waiting for a drawer that baseline wrongly closes.
  42 |    await expect.poll(async()=>await drawer.count()===0||await drawer.getByRole('button',{name:'Consultar el cambio registrado',exact:true}).count()>0).toBe(true)
  43 |    await info.attach('readback-observation',{body:JSON.stringify({mode,commands,readbacks,drawerCount:await drawer.count()}),contentType:'application/json'})
> 44 |    await expect(drawer).toBeVisible()
     |                         ^ Error: expect(locator).toBeVisible() failed
  45 |    await expect(confirm).toHaveCount(0)
  46 |    await expect(drawer.getByRole('status').filter({hasText:'El cambio está registrado. Consulta el activo para confirmar sus datos actuales.'})).toBeVisible()
  47 |    await drawer.getByRole('button',{name:'Cerrar panel',exact:true}).click()
  48 |    await expect(drawer).toBeVisible()
  49 |    corrected=true
  50 |    await drawer.getByRole('button',{name:'Consultar el cambio registrado',exact:true}).click()
  51 |    await expect.poll(()=>readbacks).toBe(2)
  52 |   }
  53 |   await expect(drawer).toHaveCount(0)
  54 |   const card=page.locator(`article[data-portfolio-id="${id}"]`)
  55 |   await expect(card.getByText(mode==='newer'?'Cancelado':'Activo',{exact:true})).toBeVisible()
  56 |   expect(commands.map(c=>c.operation)).toEqual(['contract.activate']);expect(errors).toEqual([])
  57 |   await page.screenshot({path:info.outputPath(`portfolio-${mode}.png`)})
  58 |  }finally{await page.unrouteAll({behavior:'wait'})}
  59 | })
  60 | 
```
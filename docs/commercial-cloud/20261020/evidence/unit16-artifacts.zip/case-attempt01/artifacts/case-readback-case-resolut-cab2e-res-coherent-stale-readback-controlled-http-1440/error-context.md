# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: case-readback.spec.ts >> case resolution requires coherent stale readback
- Location: tools\oier_commercial_qa\case-readback.spec.ts:9:111

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 0

Call Log:
- Timeout 4000ms exceeded while waiting on the predicate
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startCustomerResourceFixture} from '../../tests/e2e-preview/fixtures/customer-resource-server.cjs'
  3  | const id='10000000-0000-4000-8000-000000000001'
  4  | const customer={id,version:1,account_kind:'legal_entity',display_name:'Synthetic case customer',lifecycle:'customer',status:'active',source:'manual',assigned_user_id:null}
  5  | const original={id,version:1,customer_id:id,contract_id:null,service_id:null,line_id:null,case_type:'technical',title:'Synthetic resolution recovery',priority:'normal',due_on:null,assigned_user_id:null,status:'open',source:'manual',resolved_at:null,closed_at:null,resolution_code:null,cancellation_code:null,internal_note_count:0,created_at:'2026-10-01T10:00:00.000Z',updated_at:'2026-10-01T10:00:00.000Z',overdue:false}
  6  | let fixture:Awaited<ReturnType<typeof startCustomerResourceFixture>>
  7  | test.beforeAll(async()=>{fixture=await startCustomerResourceFixture()})
  8  | test.afterAll(async()=>{await fixture?.close()})
  9  | for(const mode of ['stale','wrong_status','wrong_source','wrong_resolution','confirmed','newer'] as const)test(`case resolution requires coherent ${mode} readback`,async({page},info)=>{
  10 |  const commands:string[]=[],errors:string[]=[]
  11 |  let applied=false,corrected=false,readbacks=0
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const {operation,input}=route.request().postDataJSON()
  15 |   if(route.request().url().endsWith('/commands')){
  16 |    commands.push(operation);applied=true
  17 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'case.v1',operation,command_id:input.command_id,id,version:2,status:'resolved',source:'manual',resolution_code:'issue_fixed',cancellation_code:null,note_id:null,note_seq:null}}});return
  18 |   }
  19 |   if(operation==='case.get'){
  20 |    if(applied)readbacks++
  21 |    const row=!applied||!corrected&&mode==='stale'?original:{...original,version:mode==='newer'?3:2,status:!corrected&&mode==='wrong_status'?'open':mode==='newer'?'closed':'resolved',source:!corrected&&mode==='wrong_source'?'import':'manual',resolution_code:!corrected&&mode==='wrong_status'?null:!corrected&&mode==='wrong_resolution'?'request_fulfilled':'issue_fixed',resolved_at:!corrected&&mode==='wrong_status'?null:'2026-10-02T10:00:00.000Z',closed_at:mode==='newer'?'2026-10-03T10:00:00.000Z':null,updated_at:'2026-10-03T10:00:00.000Z'}
  22 |    await route.fulfill({json:{ok:true,data:{contract_version:'case.v1',operation,record:row}}});return
  23 |   }
  24 |   if(operation==='customer.list'){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation,items:[customer],next_id:null}}});return}
  25 |   if(operation==='assignee.list'){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation,items:[],next_id:null}}});return}
  26 |   await route.fulfill({status:403,json:{ok:false,error:'access_denied'}})
  27 |  })
  28 |  try{
  29 |   await page.goto(fixture.url+'/?kind=case')
  30 |   await page.getByRole('button',{name:'Revisar resolución',exact:true}).click()
  31 |   const confirm=page.getByRole('dialog',{name:'Confirmar cambio de incidencia',exact:true})
  32 |   await confirm.getByRole('button',{name:'Confirmar cambio',exact:true}).click()
> 33 |   await expect.poll(()=>readbacks).toBe(1)
     |                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  34 |   if(!['confirmed','newer'].includes(mode)){
  35 |    await info.attach('case-readback-observation',{body:JSON.stringify({mode,commands,readbacks}),contentType:'application/json'})
  36 |    await expect(confirm).toBeVisible()
  37 |    await expect(confirm.getByRole('alert')).toBeVisible()
  38 |    await confirm.getByRole('button',{name:'Cancelar',exact:true}).click()
  39 |    const notice=page.getByRole('status').filter({hasText:'Cambio registrado. Reintentar solo actualiza la lectura.'})
  40 |    await expect(notice).toBeVisible();await notice.scrollIntoViewIfNeeded()
  41 |    await page.screenshot({path:info.outputPath(`case-${mode}-pending.png`)})
  42 |    corrected=true
  43 |    await page.getByRole('button',{name:'Actualizar incidencia confirmada',exact:true}).click()
  44 |    await expect.poll(()=>readbacks).toBe(2)
  45 |   }
  46 |   await expect(confirm).toHaveCount(0)
  47 |   await expect(page.locator('header').getByText('Resolución: Problema corregido',{exact:true})).toBeVisible()
  48 |   if(mode==='newer')await expect(page.getByRole('button',{name:'Revisar reapertura',exact:true})).toHaveCount(0)
  49 |   else await expect(page.getByRole('button',{name:'Revisar reapertura',exact:true})).toBeVisible()
  50 |   expect(commands).toEqual(['case.resolve']);expect(errors).toEqual([])
  51 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  52 |   await page.screenshot({path:info.outputPath(`case-${mode}-current.png`)})
  53 |  }finally{await page.unrouteAll({behavior:'wait'})}
  54 | })
  55 | 
```
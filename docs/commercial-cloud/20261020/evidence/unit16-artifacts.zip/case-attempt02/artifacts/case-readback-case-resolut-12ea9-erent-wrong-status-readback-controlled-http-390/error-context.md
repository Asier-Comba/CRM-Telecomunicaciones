# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: case-readback.spec.ts >> case resolution requires coherent wrong_status readback
- Location: tools\oier_commercial_qa\case-readback.spec.ts:9:111

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog', { name: 'Confirmar cambio de incidencia', exact: true }).getByRole('alert')
Expected: visible
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Confirmar cambio de incidencia', exact: true }).getByRole('alert')

```

```yaml
- banner: CRM synthetic customer fixture
- main:
  - button "Cambiar empresa sintética"
  - button "Cambiar actor sintético"
  - button "Cambiar a lector sintético"
  - text: Empresa sintética A
  - navigation "Cliente sintético seleccionado":
    - button "Seleccionar cliente A"
    - button "Seleccionar cliente B"
    - button "Seleccionar cliente C"
    - button "Seleccionar cliente D"
    - status "Referencia sintética actual": 10000000-0000-4000-8000-000000000001
    - status "Avisos de acceso": "0"
  - heading "Synthetic resolution recovery" [level=1]
  - text: Abierta Técnica Normal Sin fecha
  - paragraph:
    - link "Synthetic case customer":
      - /url: /clients/10000000-0000-4000-8000-000000000001
    - text: · Sin responsable
  - paragraph: Manual · Actualizada 03 oct 2026, 12:00 · 0 notas internas
  - navigation "Relaciones de la incidencia":
    - link "Abrir cliente":
      - /url: /clients/10000000-0000-4000-8000-000000000001
  - paragraph: Seguimiento interno. Estos cambios no notifican ni ejecutan acciones con el operador.
  - heading "Datos de incidencia" [level=2]
  - text: Título de incidencia
  - textbox "Título de incidencia": Synthetic resolution recovery
  - text: Tipo de incidencia
  - combobox "Tipo de incidencia":
    - option "Activación"
    - option "Portabilidad"
    - option "Técnica" [selected]
    - option "Facturación"
    - option "Renovación"
    - option "Cancelación"
    - option "Documentación"
    - option "Otra"
  - text: Prioridad de incidencia
  - combobox "Prioridad de incidencia":
    - option "Baja"
    - option "Normal" [selected]
    - option "Alta"
    - option "Urgente"
  - text: Vencimiento de incidencia
  - textbox "Vencimiento de incidencia"
  - button "Revisar datos de incidencia"
  - heading "Responsable de incidencia" [level=2]
  - text: Responsable
  - combobox "Responsable autorizado":
    - option "Sin responsable" [selected]
  - button "Revisar responsable de incidencia"
  - heading "Seguimiento de incidencia" [level=2]
  - text: Nuevo estado
  - combobox "Nuevo estado de incidencia":
    - option "En curso" [selected]
    - option "Esperando al cliente"
    - option "Esperando al operador"
  - button "Revisar seguimiento de incidencia"
  - text: Motivo de resolución
  - combobox "Motivo de resolución":
    - option "Problema corregido" [selected]
    - option "Solicitud atendida"
    - option "Confirmado por el cliente"
    - option "No requiere actuación"
  - button "Revisar resolución"
  - text: Motivo de cancelación
  - combobox "Motivo de cancelación de incidencia":
    - option "El cliente retiró la solicitud" [selected]
    - option "Duplicada"
    - option "Ya no es necesaria"
    - option "Registro incorrecto"
  - button "Revisar cancelación de incidencia"
  - heading "Notas internas de incidencia" [level=2]
  - button "Consultar notas internas"
  - text: Nueva nota interna
  - textbox "Nueva nota interna de incidencia"
  - button "Revisar nota interna" [disabled]
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startCustomerResourceFixture} from '../../tests/e2e-preview/fixtures/customer-resource-server.cjs'
  3  | const id='10000000-0000-4000-8000-000000000001'
  4  | const customer={id,version:1,account_kind:'legal_entity',display_name:'Synthetic case customer',lifecycle:'customer',status:'active',source:'manual',assigned_user_id:null}
  5  | const original={id,version:1,customer_id:id,contract_id:null,service_id:null,line_id:null,case_type:'technical',title:'Synthetic resolution recovery',priority:'normal',due_on:null,assigned_user_id:null,status:'open',source:'manual',resolved_at:null,closed_at:null,resolution_code:null,cancellation_code:null,internal_note_count:0,created_at:'2026-10-01T10:00:00.000Z',updated_at:'2026-10-01T10:00:00.000Z',overdue:false}
  6  | let fixture:Awaited<ReturnType<typeof startCustomerResourceFixture>>
  7  | test.beforeAll(async()=>{fixture=await startCustomerResourceFixture()})
  8  | test.afterAll(async()=>{await fixture?.close()})
  9  | for(const mode of ['stale','wrong_status','wrong_source','wrong_resolution','confirmed','newer'] as const)test(`case resolution requires coherent ${mode} readback`,async({page},info)=>{
  10 |  const commands:string[]=[],errors:string[]=[]
  11 |  let applied=false,corrected=false,readbacks=0
  12 |  page.on('pageerror',e=>errors.push(e.message))
  13 |  await page.route('**/api/**',async route=>{
  14 |   const {operation,input}=route.request().postDataJSON()
  15 |   if(operation==='case.resolve'){
  16 |    commands.push(operation);applied=true
  17 |    await route.fulfill({json:{ok:true,data:{contract_version:'case.v1',operation,command_id:input.command_id,id,version:2,status:'resolved',source:'manual',resolution_code:'issue_fixed',cancellation_code:null,note_id:null,note_seq:null}}});return
  18 |   }
  19 |   if(operation==='case.get'){
  20 |    if(applied)readbacks++
  21 |    const row=!applied||!corrected&&mode==='stale'?original:{...original,version:mode==='newer'?3:2,status:!corrected&&mode==='wrong_status'?'open':mode==='newer'?'closed':'resolved',source:!corrected&&mode==='wrong_source'?'import':'manual',resolution_code:!corrected&&mode==='wrong_status'?null:!corrected&&mode==='wrong_resolution'?'request_fulfilled':'issue_fixed',resolved_at:!corrected&&mode==='wrong_status'?null:'2026-10-02T10:00:00.000Z',closed_at:mode==='newer'?'2026-10-03T10:00:00.000Z':null,updated_at:'2026-10-03T10:00:00.000Z'}
  22 |    await route.fulfill({json:{ok:true,data:{contract_version:'case.v1',operation,record:row}}});return
  23 |   }
  24 |   if(operation==='customer.list'){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation,items:[customer],next_id:null}}});return}
  25 |   if(operation==='assignee.list'){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation,items:[],next_id:null}}});return}
  26 |   await route.fulfill({status:403,json:{ok:false,error:'access_denied'}})
  27 |  })
  28 |  try{
  29 |   await page.goto(fixture.url+'/?kind=case')
  30 |   await page.getByRole('button',{name:'Revisar resolución',exact:true}).click()
  31 |   const confirm=page.getByRole('dialog',{name:'Confirmar cambio de incidencia',exact:true})
  32 |   await confirm.getByRole('button',{name:'Confirmar cambio',exact:true}).click()
  33 |   await expect.poll(()=>readbacks).toBe(1)
  34 |   if(!['confirmed','newer'].includes(mode)){
  35 |    await info.attach('case-readback-observation',{body:JSON.stringify({mode,commands,readbacks}),contentType:'application/json'})
  36 |    await expect(confirm).toBeVisible()
> 37 |    await expect(confirm.getByRole('alert')).toBeVisible()
     |                                             ^ Error: expect(locator).toBeVisible() failed
  38 |    await confirm.getByRole('button',{name:'Cancelar',exact:true}).click()
  39 |    const notice=page.getByRole('status').filter({hasText:'Cambio registrado. Reintentar solo actualiza la lectura.'})
  40 |    await expect(notice).toBeVisible();await notice.scrollIntoViewIfNeeded()
  41 |    await page.screenshot({path:info.outputPath(`case-${mode}-pending.png`)})
  42 |    corrected=true
  43 |    await page.getByRole('button',{name:'Actualizar incidencia confirmada',exact:true}).click()
  44 |    await expect.poll(()=>readbacks).toBe(2)
  45 |   }
  46 |   await expect(confirm).toHaveCount(0)
  47 |   await expect(page.locator('header').getByText('Resolución: Problema corregido',{exact:true})).toBeVisible()
  48 |   if(mode==='newer')await expect(page.getByRole('button',{name:'Revisar reapertura',exact:true})).toHaveCount(0)
  49 |   else await expect(page.getByRole('button',{name:'Revisar reapertura',exact:true})).toBeVisible()
  50 |   expect(commands).toEqual(['case.resolve']);expect(errors).toEqual([])
  51 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  52 |   await page.screenshot({path:info.outputPath(`case-${mode}-current.png`)})
  53 |  }finally{await page.unrouteAll({behavior:'wait'})}
  54 | })
  55 | 
```
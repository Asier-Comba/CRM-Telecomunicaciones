# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: inbox-intent.spec.ts >> inbox create preserves reviewed intent after wrong_receipt
- Location: tools\oier_commercial_qa\inbox-intent.spec.ts:7:140

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  getByRole('dialog', { name: 'Nueva conversación interna', exact: true }).getByRole('textbox', { name: 'Primera nota interna', exact: true })
Expected: disabled
Received: enabled
Timeout:  4000ms

Call log:
  - Expect "toBeDisabled" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Nueva conversación interna', exact: true }).getByRole('textbox', { name: 'Primera nota interna', exact: true })
    12 × locator resolved to <textarea maxlength="4000" aria-label="Primera nota interna" class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 disabled:opacity-50 mt-1 min-h-32 w-full">Nota interna sintética revisada</textarea>
       - unexpected value "enabled"

```

```yaml
- textbox "Primera nota interna": Nota interna sintética revisada
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startInboxContactPaginationFixture} from '../../tests/e2e-preview/fixtures/inbox-contact-pagination-server.cjs'
  3  | const old='10000000-0000-4000-8000-000000000001',created='10000000-0000-4000-8000-000000000002',body='Nota interna sintética revisada'
  4  | let fixture:Awaited<ReturnType<typeof startInboxContactPaginationFixture>>
  5  | test.beforeAll(async()=>{fixture=await startInboxContactPaginationFixture()})
  6  | test.afterAll(async()=>{await fixture?.close()})
  7  | for(const action of ['note','create'] as const)for(const mode of ['transport','malformed','wrong_receipt','denied','success'] as const)test(`inbox ${action} preserves reviewed intent after ${mode}`,async({page},info)=>{
  8  |  const commands:{operation:string;input:Record<string,unknown>}[]=[],effects=new Set<string>(),errors:string[]=[]
  9  |  const id=action==='create'?created:old
  10 |  const record=(value:string)=>({id:value,version:value===id&&effects.size? action==='create'?1:2:1,status:'open',channel:'internal',source:'manual_internal',assigned_user_id:null,customer_id:null,contact_id:null,last_seq:value===id&&effects.size?1:0,created_at:'2026-10-11T09:00:00Z',updated_at:'2026-10-11T09:00:00Z',read_version:0,unread:false})
  11 |  page.on('pageerror',e=>errors.push(e.message))
  12 |  await page.route('**/api/**',async route=>{
  13 |   const q=route.request().postDataJSON();let data:unknown
  14 |   if(['conversation.create_internal','message.add_internal_note'].includes(q.operation)){
  15 |    commands.push(q)
  16 |    if(mode==='denied'){await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  17 |    effects.add(q.input.command_id)
  18 |    if(commands.length===1&&mode==='transport'){await route.abort('failed');return}
  19 |    if(commands.length===1&&mode==='malformed'){await route.fulfill({contentType:'application/json',body:'{'});return}
  20 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'inbox.v1',operation:q.operation,command_id:commands.length===1&&mode==='wrong_receipt'?'70000000-0000-4000-8000-000000000009':q.input.command_id,id,version:action==='create'?1:2,status:'open'}}});return
  21 |   }
  22 |   if(q.operation==='inbox.list')data={contract_version:'inbox.v1',operation:q.operation,items:action==='create'&&effects.size?[record(old),record(created)]:[record(old)],next_id:null}
  23 |   else if(q.operation==='inbox.get_thread')data={contract_version:'inbox.v1',operation:q.operation,conversation:record(q.input.id),messages:q.input.id===id&&effects.size?[{id:'30000000-0000-4000-8000-000000000001',seq:1,kind:'internal_note',body,actor_user_id:'40000000-0000-4000-8000-000000000001',created_at:'2026-10-11T09:00:00Z'}]:[],next_seq:null,provider_status:'not_configured'}
  24 |   else if(q.operation==='inbox.unread_summary')data={contract_version:'inbox.v1',operation:q.operation,unread_count:0}
  25 |   else{await route.fulfill({status:400,json:{ok:false,error:'validation'}});return}
  26 |   await route.fulfill({json:{ok:true,data}})
  27 |  })
  28 |  try{
  29 |   await page.goto(fixture.url)
  30 |   if(action==='create')await page.getByRole('button',{name:'Nueva conversación',exact:true}).click()
  31 |   const dialog=page.getByRole('dialog',{name:'Nueva conversación interna',exact:true})
  32 |   const scope=action==='create'?dialog:page
  33 |   const field=scope.getByRole('textbox',{name:action==='create'?'Primera nota interna':'Nueva nota interna',exact:true})
  34 |   await expect(field).toBeVisible();await field.fill(body)
  35 |   await scope.getByRole('button',{name:action==='create'?'Crear conversación':'Guardar nota',exact:true}).click()
  36 |   await expect.poll(()=>commands.length).toBe(1)
  37 |   if(['transport','malformed','wrong_receipt'].includes(mode)){
> 38 |    await expect(field).toBeDisabled();await expect(field).toHaveValue(body)
     |                        ^ Error: expect(locator).toBeDisabled() failed
  39 |    const retry=scope.getByRole('button',{name:'Comprobar la misma acción',exact:true})
  40 |    await expect(retry).toBeEnabled()
  41 |    await expect(page.getByRole('button',{name:'Nueva conversación',exact:true,includeHidden:true})).toBeDisabled()
  42 |    if(action==='create'){
  43 |     await dialog.getByRole('button',{name:'Cerrar panel',exact:true}).click({force:true});await expect(dialog).toBeVisible()
  44 |     await page.keyboard.press('Escape');await expect(dialog).toBeVisible()
  45 |    }
  46 |    await retry.click();await expect.poll(()=>commands.length).toBe(2)
  47 |    expect(commands[1]).toEqual(commands[0])
  48 |   }else if(mode==='denied'){
  49 |    await expect(field).toBeEnabled();await expect(field).toHaveValue(body)
  50 |    expect(effects.size).toBe(0)
  51 |   }
  52 |   if(mode!=='denied'){
  53 |    if(action==='create')await expect(dialog).toHaveCount(0)
  54 |    await expect(page.getByText(body,{exact:true})).toBeVisible()
  55 |    expect(effects.size).toBe(1)
  56 |    expect(commands[0].input.body).toBe(body)
  57 |    expect(commands[0].operation).toBe(action==='create'?'conversation.create_internal':'message.add_internal_note')
  58 |   }
  59 |   expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  60 |   await page.screenshot({path:info.outputPath(`inbox-${action}-${mode}.png`)})
  61 |  }finally{await page.close()}
  62 | })
  63 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: opportunity-archive.spec.ts >> opportunity archive confirmation keeps wrong_receipt intent
- Location: tools\oier_commercial_qa\opportunity-archive.spec.ts:8:108

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('dialog', { name: 'Archivar oportunidad', exact: true })
Expected: visible
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Archivar oportunidad', exact: true })

```

```yaml
- banner: CRM synthetic pipeline fixture
- main:
  - button "Cambiar empresa sintética"
  - button "Cambiar actor sintético"
  - button "Cambiar a lector sintético"
  - text: Empresa sintética A
  - textbox "Consultar pipeline local":
    - /placeholder: Buscar empresa u oportunidad
    - text: sintética
  - button "Consultar pipeline"
  - paragraph: Hasta cinco oportunidades y cinco clientes por consulta. Las columnas usan el catálogo autorizado de etapas; los recuentos corresponden a los resultados visibles.
  - heading "Oportunidades" [level=1]
  - paragraph: Pipeline comercial, responsables y próximas acciones
  - button "Nueva oportunidad"
  - strong: Integración local
  - text: · Datos sintéticos de prueba · Cambios guardados en la base local
  - button "Mostrar resumen del pipeline"
  - textbox "Buscar oportunidades":
    - /placeholder: Buscar oportunidad o empresa
  - combobox "Comercial de oportunidad":
    - option "Todos los comerciales" [selected]
    - option "Sin asignar"
  - button "Vista pipeline" [pressed]
  - button "Vista lista"
  - heading "Nueva sintética 1" [level=2]
  - button "Oportunidad sintética con archivo revisado Empresa sintética de archivo 100,00 € Abierta Sin comercial Fecha de seguimiento no disponible":
    - paragraph: Oportunidad sintética con archivo revisado
    - paragraph: Empresa sintética de archivo
    - text: 100,00 € Abierta
    - paragraph: Sin comercial
    - paragraph: Fecha de seguimiento no disponible
  - text: Mover a etapa
  - combobox "Mover etapa de Oportunidad sintética con archivo revisado":
    - option "Nueva sintética" [selected]
  - heading "Definición del pipeline" [level=2]
  - paragraph: Arrastra una oportunidad manual abierta o usa su selector de etapa. Las etapas de cierre se revisan en el detalle. El movimiento se confirma al guardar y consultar el registro.
  - dialog "Detalle de oportunidad":
    - heading "Detalle de oportunidad" [level=2]
    - button "Cerrar panel"
    - text: Abierta
    - paragraph: "Origen: Manual"
    - button "Comprobar origen registrado"
    - group:
      - text: Título comercial
      - textbox "Título comercial": Oportunidad sintética con archivo revisado
      - paragraph: Empresa vinculada · El vínculo se conserva al editar.
      - text: Importe
      - textbox "Importe": "100"
      - text: Moneda
      - combobox "Moneda":
        - option "EUR" [selected]
        - option "USD"
        - option "GBP"
      - text: Cierre previsto
      - textbox "Cierre previsto"
      - text: Próxima acción
      - textbox "Próxima acción"
      - text: Etapa
      - combobox "Etapa comercial":
        - option "Nueva sintética" [selected]
    - region "Productos de la oportunidad":
      - heading "Productos vinculados" [level=3]
      - paragraph: Los cambios se guardan con la oportunidad. Seleccionar un contrato quita el servicio anterior; seleccionar un servicio conserva su contrato autorizado.
      - paragraph: Sin contrato o servicio seleccionado.
      - text: Buscar productos de esta empresa
      - textbox "Buscar productos de esta empresa"
      - button "Consultar productos autorizados" [disabled]
      - paragraph: Hasta cinco contratos y cinco servicios por consulta. Solo se pueden seleccionar registros de esta empresa.
    - button "Guardar oportunidad"
    - button "Aplicar etapa"
    - button "Archivar oportunidad"
    - text: Responsable
    - combobox "Responsable autorizado":
      - option "Seleccionar responsable" [disabled] [selected]
    - button "Guardar responsable" [disabled]
    - heading "Historial de cambios" [level=3]
    - heading "Productos vinculados" [level=3]
    - paragraph: Sin vínculos de producto registrados.
    - paragraph: La selección de nuevos productos necesita el catálogo autorizado del cliente.
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startPipelineCurrentFixture} from '../../tests/e2e-preview/fixtures/pipeline-current-server.cjs'
  3  | const customer='10000000-0000-4000-8000-000000000001',stage='20000000-0000-4000-8000-000000000001',id='30000000-0000-4000-8000-000000000001'
  4  | const title='Oportunidad sintética con archivo revisado'
  5  | let fixture:Awaited<ReturnType<typeof startPipelineCurrentFixture>>
  6  | test.beforeAll(async()=>{fixture=await startPipelineCurrentFixture()})
  7  | test.afterAll(async()=>{await fixture?.close()})
  8  | for(const mode of ['transport','malformed','wrong_receipt','read_failure','denied','success'] as const)test(`opportunity archive confirmation keeps ${mode} intent`,async({page},info)=>{
  9  |  const commands:{operation:string;input:Record<string,unknown>}[]=[],effects=new Set<string>(),errors:string[]=[]
  10 |  let applied=false,readsAfter=0
  11 |  page.on('pageerror',e=>errors.push(e.message))
  12 |  await page.route('**/api/**',async route=>{
  13 |   const q=route.request().postDataJSON();let data:unknown
  14 |   if(route.request().url().endsWith('/commands')){
  15 |    commands.push(q)
  16 |    if(q.operation!=='opportunity.archive'||mode==='denied'){await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  17 |    applied=true;effects.add(q.input.command_id)
  18 |    if(commands.length===1&&mode==='transport'){await route.abort('failed');return}
  19 |    if(commands.length===1&&mode==='malformed'){await route.fulfill({contentType:'application/json',body:'{'});return}
  20 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'product.v1',operation:q.operation,command_id:commands.length===1&&mode==='wrong_receipt'?'70000000-0000-4000-8000-000000000009':q.input.command_id,id,version:2,status:'cancelled'}}});return
  21 |   }
  22 |   if(q.operation==='opportunity.stages')data={contract_version:'product.v1',items:[{id:stage,code:'new',display_name:'Nueva sintética',position:0,outcome:null,status:'active'}],next_id:null}
  23 |   else if(q.operation==='global.search')data={contract_version:'product.v1',items:[{kind:'customer',id:customer,customer_id:customer,label:'Empresa sintética de archivo',status:'active'},{kind:'opportunity',id,customer_id:customer,label:title,status:'open'}]}
  24 |   else if(q.operation==='assignee.list')data={contract_version:'telecom.collections.v1',operation:q.operation,items:[],next_id:null}
  25 |   else if(q.operation==='work.get'){
  26 |    if(applied)readsAfter++
  27 |    if(applied&&mode==='read_failure'&&readsAfter===1){await route.fulfill({status:500,json:{ok:false,error:'internal_safe'}});return}
  28 |    data={contract_version:'product.v1',kind:'opportunity',record:{id,version:applied?2:1,title,status:applied?'cancelled':'open',customer_id:customer,stage_id:stage,owner_user_id:null,amount_minor:10000,currency:'EUR',next_follow_up_at:null,expected_close_date:null,next_action:null,source:'manual',links:[],history:[],history_partial:false}}
  29 |   }else{await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  30 |   await route.fulfill({json:{ok:true,data}})
  31 |  })
  32 |  try{
  33 |   await page.goto(fixture.url)
  34 |   await page.getByRole('textbox',{name:'Consultar pipeline local',exact:true}).fill('sintética')
  35 |   await page.getByRole('button',{name:'Consultar pipeline',exact:true}).click()
  36 |   await page.locator(`[data-opportunity-id="${id}"]`).click()
  37 |   const editor=page.getByRole('dialog',{name:'Detalle de oportunidad',exact:true}),confirm=page.getByRole('dialog',{name:'Archivar oportunidad',exact:true})
  38 |   await editor.getByRole('button',{name:'Archivar oportunidad',exact:true}).click()
  39 |   await confirm.getByRole('button',{name:'Confirmar',exact:true}).click()
  40 |   await expect.poll(()=>commands.length).toBe(1)
  41 |   if(['transport','malformed','wrong_receipt'].includes(mode)){
  42 |    await expect(confirm.getByRole('alert')).toBeVisible()
  43 |    const cancel=confirm.getByRole('button',{name:'Cancelar',exact:true}),close=confirm.getByRole('button',{name:'Cerrar',exact:true})
  44 |    // Start with a different native closing surface at each width; keep all assertions.
  45 |    const width=page.viewportSize()!.width
  46 |    if(width===390)await cancel.click({force:true})
  47 |    else if(width===768)await close.click({force:true})
  48 |    else await page.keyboard.press('Escape')
> 49 |    await expect(confirm).toBeVisible()
     |                          ^ Error: expect(locator).toBeVisible() failed
  50 |    await cancel.click({force:true});await expect(confirm).toBeVisible()
  51 |    await close.click({force:true});await expect(confirm).toBeVisible()
  52 |    await page.keyboard.press('Escape');await expect(confirm).toBeVisible()
  53 |    await expect(cancel).toBeDisabled();await expect(close).toBeDisabled()
  54 |    await page.screenshot({path:info.outputPath(`opportunity-archive-${mode}-pending.png`)})
  55 |    const retry=confirm.getByRole('button',{name:/^(Confirmar|Reintentar el mismo archivo)$/})
  56 |    await retry.click();await expect.poll(()=>commands.length).toBe(2);expect(commands[1]).toEqual(commands[0])
  57 |   }else if(mode==='read_failure'){
  58 |    await expect(confirm).toHaveCount(0);await expect(editor.getByRole('alert')).toBeVisible()
  59 |    await editor.getByRole('button',{name:'Cerrar panel',exact:true}).click({force:true});await expect(editor).toBeVisible()
  60 |    await page.keyboard.press('Escape');await expect(editor).toBeVisible()
  61 |    await editor.getByRole('button',{name:'Consultar la oportunidad guardada',exact:true}).click()
  62 |    await expect.poll(()=>readsAfter).toBe(2);expect(commands).toHaveLength(1)
  63 |   }else if(mode==='denied'){
  64 |    await expect(confirm.getByRole('alert')).toBeVisible();await expect(confirm.getByRole('button',{name:'Cancelar',exact:true})).toBeEnabled()
  65 |    await confirm.getByRole('button',{name:'Cancelar',exact:true}).click();await expect(confirm).toHaveCount(0)
  66 |    await expect(editor.getByRole('textbox',{name:'Título comercial',exact:true})).toBeEnabled()
  67 |    await editor.getByRole('button',{name:'Cerrar panel',exact:true}).click();await expect(editor).toHaveCount(0);expect(effects.size).toBe(0)
  68 |   }
  69 |   if(mode!=='denied'){
  70 |    await expect(editor).toHaveCount(0);await expect(confirm).toHaveCount(0)
  71 |    await expect(page.locator(`[data-opportunity-id="${id}"]`)).toContainText('Cancelado')
  72 |    await expect(page.getByRole('combobox',{name:'Mover etapa de '+title,exact:true})).toHaveCount(0);expect(effects.size).toBe(1)
  73 |   }
  74 |   expect(commands.every(q=>q.operation==='opportunity.archive')).toBe(true)
  75 |   expect(commands[0].input).toMatchObject({id,expected_version:1})
  76 |   expect(Object.keys(commands[0].input).sort()).toEqual(['command_id','expected_version','id'])
  77 |   expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  78 |   await page.screenshot({path:info.outputPath(`opportunity-archive-${mode}-result.png`)})
  79 |  }finally{await page.close()}
  80 | })
  81 | 
```
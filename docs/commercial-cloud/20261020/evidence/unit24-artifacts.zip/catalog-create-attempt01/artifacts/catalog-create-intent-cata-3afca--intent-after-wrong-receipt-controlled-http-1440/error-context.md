# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: catalog-create-intent.spec.ts >> catalog operator creation preserves reviewed intent after wrong_receipt
- Location: tools\oier_commercial_qa\catalog-create-intent.spec.ts:7:93

# Error details

```
Error: expect(locator).toBeEnabled() failed

Locator: getByRole('dialog', { name: 'Nuevo operador', exact: true }).getByRole('button', { name: 'Comprobar la misma alta', exact: true })
Expected: enabled
Timeout: 4000ms
Error: element(s) not found

Call log:
  - Expect "toBeEnabled" with timeout 4000ms
  - waiting for getByRole('dialog', { name: 'Nuevo operador', exact: true }).getByRole('button', { name: 'Comprobar la misma alta', exact: true })

```

```yaml
- banner: CRM synthetic catalog resource fixture
- main:
  - button "Cambiar empresa sintética"
  - button "Cambiar actor sintético"
  - button "Cambiar a lector sintético"
  - text: Empresa sintética A
  - heading "Catálogo Telecom" [level=1]
  - paragraph: Operadores, tarifas y versiones comerciales publicadas
  - button "Nuevo operador"
  - strong: Integración local
  - text: · Datos sintéticos de prueba · Cambios guardados en la base local
  - tablist "Secciones":
    - tab "Operadores" [selected]
    - tab "Tarifas"
    - tab "Versiones"
  - tabpanel "Operadores":
    - combobox "Estado del catálogo":
      - option "Todos los estados" [selected]
      - option "Activo"
      - option "Inactivo"
    - button "Actualizar catálogo"
    - paragraph: No hay registros de catálogo con estos filtros.
    - button "Página anterior del catálogo" [disabled]
    - text: Página 1 · 0 registros
    - button "Siguiente página del catálogo" [disabled]
  - dialog "Nuevo operador":
    - heading "Nuevo operador" [level=2]
    - button "Cerrar panel"
    - alert: No se pudo completar la acción.
    - group:
      - text: Nombre
      - textbox "Nombre de alta de catálogo" [disabled]: Operador sintético controlado
      - text: Código
      - textbox "Código de alta de catálogo" [disabled]: oier_synthetic
      - text: Letras minúsculas, números, guion o guion bajo. El código identifica el registro y se conserva.
    - paragraph: "Alta manual de operador: Operador sintético controlado · oier_synthetic."
    - button "Confirmar alta de catálogo"
    - button "Volver a editar"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startCatalogResourceFixture} from '../../tests/e2e-preview/fixtures/catalog-resource-server.cjs'
  3  | const id='20000000-0000-4000-8000-000000000001',name='Operador sintético controlado',code='oier_synthetic'
  4  | let fixture:Awaited<ReturnType<typeof startCatalogResourceFixture>>
  5  | test.beforeAll(async()=>{fixture=await startCatalogResourceFixture()})
  6  | test.afterAll(async()=>{await fixture?.close()})
  7  | for(const mode of ['transport','malformed','wrong_receipt','denied','success'] as const)test(`catalog operator creation preserves reviewed intent after ${mode}`,async({page},info)=>{
  8  |  const commands:{operation:string;input:Record<string,unknown>}[]=[],effects=new Set<string>(),errors:string[]=[]
  9  |  const record={id,version:1,code,display_name:name,status:'active',source:'manual'}
  10 |  page.on('pageerror',e=>errors.push(e.message))
  11 |  await page.route('**/api/**',async route=>{
  12 |   const q=route.request().postDataJSON();let data:unknown
  13 |   if(q.operation==='operator.create'){
  14 |    commands.push(q)
  15 |    if(mode==='denied'){await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  16 |    effects.add(q.input.command_id)
  17 |    if(commands.length===1&&mode==='transport'){await route.abort('failed');return}
  18 |    if(commands.length===1&&mode==='malformed'){await route.fulfill({contentType:'application/json',body:'{'});return}
  19 |    data={contract_version:'catalog.v1',operation:q.operation,command_id:commands.length===1&&mode==='wrong_receipt'?'70000000-0000-4000-8000-000000000009':q.input.command_id,id,version:1,status:'active'}
  20 |   }else if(q.operation==='operator.list')data={contract_version:'telecom.collections.v1',operation:q.operation,items:effects.size?[record]:[],next_id:null}
  21 |   else if(q.operation==='operator.get')data={contract_version:'telecom.collections.v1',operation:q.operation,record}
  22 |   else{await route.fulfill({status:403,json:{ok:false,error:'access_denied'}});return}
  23 |   // Telecom catalog commands use the closed data envelope, not receipt.
  24 |   await route.fulfill({json:{ok:true,data}})
  25 |  })
  26 |  try{
  27 |   await page.goto(fixture.url+'/?qa_catalog=1')
  28 |   await page.getByRole('button',{name:'Nuevo operador',exact:true}).click()
  29 |   const dialog=page.getByRole('dialog',{name:'Nuevo operador',exact:true})
  30 |   const field=dialog.getByRole('textbox',{name:'Nombre de alta de catálogo',exact:true})
  31 |   await field.fill(name);await dialog.getByRole('textbox',{name:'Código de alta de catálogo',exact:true}).fill(code)
  32 |   await dialog.getByRole('button',{name:'Revisar alta de catálogo',exact:true}).click()
  33 |   await dialog.getByRole('button',{name:'Confirmar alta de catálogo',exact:true}).click()
  34 |   await expect.poll(()=>commands.length).toBe(1)
  35 |   if(['transport','malformed','wrong_receipt'].includes(mode)){
  36 |    const retry=dialog.getByRole('button',{name:'Comprobar la misma alta',exact:true})
> 37 |    await expect(retry).toBeEnabled();await expect(field).toBeDisabled();await expect(field).toHaveValue(name)
     |                        ^ Error: expect(locator).toBeEnabled() failed
  38 |    await expect(dialog.getByRole('textbox',{name:'Código de alta de catálogo',exact:true})).toHaveValue(code)
  39 |    await dialog.getByRole('button',{name:'Cerrar panel',exact:true}).click({force:true});await expect(dialog).toBeVisible()
  40 |    await page.keyboard.press('Escape');await expect(dialog).toBeVisible()
  41 |    await page.screenshot({path:info.outputPath(`catalog-create-${mode}-unconfirmed.png`)})
  42 |    await retry.click();await expect.poll(()=>commands.length).toBe(2);expect(commands[1]).toEqual(commands[0])
  43 |   }else if(mode==='denied'){
  44 |    await expect(dialog.getByRole('alert')).toBeVisible()
  45 |    await expect(dialog.getByRole('button',{name:'Comprobar la misma alta',exact:true})).toHaveCount(0)
  46 |    expect(effects.size).toBe(0)
  47 |    await dialog.getByRole('button',{name:'Cerrar panel',exact:true}).click();await expect(dialog).toHaveCount(0)
  48 |   }
  49 |   if(mode!=='denied'){
  50 |    await expect(dialog).toHaveCount(0)
  51 |    await expect(page.getByRole('dialog',{name,exact:true})).toBeVisible()
  52 |    expect(effects.size).toBe(1)
  53 |    expect(commands[0].input).toMatchObject({display_name:name,code})
  54 |   }
  55 |   expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  56 |   await page.screenshot({path:info.outputPath(`catalog-create-${mode}.png`)})
  57 |  }finally{await page.close()}
  58 | })
  59 | 
```
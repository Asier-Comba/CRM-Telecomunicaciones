# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: contract-shortcut.spec.ts >> new manual contract follows the shortcut intent
- Location: tools\oier_commercial_qa\contract-shortcut.spec.ts:9:64

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  getByRole('dialog').getByRole('combobox', { name: 'Tipo de registro', exact: true })
Expected: "contract"
Received: "service"
Timeout:  4000ms

Call log:
  - Expect "toHaveValue" with timeout 4000ms
  - waiting for getByRole('dialog').getByRole('combobox', { name: 'Tipo de registro', exact: true })
    12 × locator resolved to <select aria-label="Tipo de registro" class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 disabled:opacity-50 w-full">…</select>
       - unexpected value "service"

```

```yaml
- combobox "Tipo de registro":
  - option "Servicio" [selected]
  - option "Renovación"
  - option "Permanencia"
  - option "Contrato"
```

# Test source

```ts
  1  | import {expect,test} from '@playwright/test'
  2  | import {startCommercialResourceFixture} from '../../tests/e2e-preview/fixtures/commercial-resource-server.cjs'
  3  | const parentId='60000000-0000-4000-8000-000000000001',createdId='70000000-0000-4000-8000-000000000002',customer='10000000-0000-4000-8000-000000000001'
  4  | const parent={id:parentId,version:1,status:'active',source:'manual',customer_id:customer,operator_id:'20000000-0000-4000-8000-000000000001',plan_version_id:null,start_date:'2026-10-01',signed_date:'2026-10-01',end_date:null,assigned_user_id:null}
  5  | const created={...parent,id:createdId,status:'draft',start_date:'2026-10-20',signed_date:null}
  6  | let fixture:Awaited<ReturnType<typeof startCommercialResourceFixture>>
  7  | test.beforeAll(async()=>{fixture=await startCommercialResourceFixture()})
  8  | test.afterAll(async()=>{await fixture?.close()})
  9  | for(const mode of ['shortcut','manual_selection'] as const)test(`new manual contract follows the ${mode} intent`,async({page},info)=>{
  10 |  const commands:{operation:string;input:{command_id:string;customer_id:string;operator_id:string;start_date:string}}[]=[],errors:string[]=[]
  11 |  page.on('pageerror',e=>errors.push(e.message))
  12 |  await page.route('**/api/**',async route=>{
  13 |   const q=route.request().postDataJSON()
  14 |   if(route.request().url().endsWith('/commands')){
  15 |    commands.push(q)
  16 |    await route.fulfill({json:{ok:true,receipt:{contract_version:'portfolio.v1',operation:q.operation,command_id:q.input.command_id,id:createdId,version:1,status:'draft',source:'manual'}}});return
  17 |   }
  18 |   if(q.operation==='global.search'){await route.fulfill({json:{ok:true,data:{contract_version:'product.v1',items:[{kind:'customer',id:customer,customer_id:customer,label:'Synthetic new contract customer',status:'active'},{kind:'contract',id:parentId,customer_id:customer,label:'Synthetic parent contract',status:'active'}]}}});return}
  19 |   if(q.operation==='portfolio.get'){await route.fulfill({json:{ok:true,data:{contract_version:'portfolio.v1',kind:'contract',record:q.input.id===createdId?created:parent}}});return}
  20 |   if(['contract.list','service.list','line.list','assignee.list','customer.list'].includes(q.operation)){await route.fulfill({json:{ok:true,data:{contract_version:'telecom.collections.v1',operation:q.operation,items:[],next_id:null}}});return}
  21 |   await route.fulfill({status:403,json:{ok:false,error:'access_denied'}})
  22 |  })
  23 |  try{
  24 |   await page.goto(fixture.url+'/?kind=portfolio')
  25 |   await page.getByRole('textbox',{name:'Consultar cartera local',exact:true}).fill('Synthetic')
  26 |   await page.getByRole('button',{name:'Consultar cartera',exact:true}).click()
  27 |   const shortcut=page.getByRole('button',{name:'Nuevo contrato manual',exact:true})
  28 |   await expect(shortcut).toBeVisible()
  29 |   if(mode==='shortcut')await shortcut.click()
  30 |   else await page.locator(`article[data-portfolio-id="${parentId}"]`).getByRole('button',{name:'Añadir servicio o plazo',exact:true}).click()
  31 |   const drawer=page.getByRole('dialog'),kind=drawer.getByRole('combobox',{name:'Tipo de registro',exact:true})
  32 |   await expect(drawer).toHaveCount(1)
  33 |   if(mode==='manual_selection')await kind.selectOption('contract')
  34 |   await info.attach('creation-kind-observation',{body:JSON.stringify({mode,selectedKind:await kind.inputValue(),commands}),contentType:'application/json'})
> 35 |   await expect(kind).toHaveValue('contract')
     |                      ^ Error: expect(locator).toHaveValue(expected) failed
  36 |   await expect(drawer.getByRole('combobox',{name:'Cliente del contrato',exact:true})).toHaveValue(customer)
  37 |   await expect(drawer.getByLabel('Nombre del nuevo activo',{exact:true})).toHaveCount(0)
  38 |   await drawer.getByLabel('Fecha de inicio',{exact:true}).fill(created.start_date)
  39 |   await drawer.getByRole('button',{name:/^Guardar (activo|contrato) manual$/}).click()
  40 |   await expect(drawer).toHaveCount(0)
  41 |   await expect(page.locator(`article[data-portfolio-id="${createdId}"]`)).toBeVisible()
  42 |   expect(commands).toHaveLength(1);expect(commands[0].operation).toBe('contract.create_manual')
  43 |   expect(commands[0].input).toEqual({command_id:expect.any(String),customer_id:customer,operator_id:parent.operator_id,start_date:created.start_date})
  44 |   expect(errors).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true)
  45 |   await page.locator(`article[data-portfolio-id="${createdId}"]`).scrollIntoViewIfNeeded()
  46 |   await page.screenshot({path:info.outputPath(`contract-${mode}-registered.png`)})
  47 |  }finally{await page.close()}
  48 | })
  49 | 
```